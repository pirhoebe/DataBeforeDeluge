
source("R - 14C paper 3/scripts/read libraries.R")
source("R - 14C paper 3/SupplMat scripts/PPcalibrate_custom.R")

Adata <- read_excel("~/Archeologie PhD/- DATA ANALYSIS/R - prey prevalence/data/SupMat dataset.xlsx")
Adata <- Adata%>%filter(!is.na(species))
Adata <- Adata%>%filter(material %in%c("antler","bone", "bone collagen",
                                       "botanical remains" ,"tooth / ivory"))
Adata <- rename(Adata, sitename=site)

levels(as.factor(Adata$species))


tundra <- filter(Adata, species %in%c(
  "Capra",
  "Equus",
  "Ovibos",
  "Panthera",
  "Phasianidae",
  "Rangifer",
  "Saiga",
  "Ursus"))

forest <- filter(Adata, species %in%c(
  "Alces",
  "Alces/Bos",
  "Bison",
  "Bos",
  "Bos/Bison",
  "Capreolus",
  "Castor",
  "Cervidae",
  "Cervus",
  "Lynx",
  "Megaloceros",
  "Sus"))



#_____________________________________________________________________________
##### COMPARATIVE DATASETS ####
### load intcal20 data ####
INTCAL20 <- read.csv('https://www.intcal.org/curves/intcal20.14c',
                     encoding="UTF-8",skip=11,header=F)
colnames(INTCAL20) <- c("BP","CRA","Error","D14C","Sigma")

### load NGRIP data ###
NGRIP<- pg_data(doi='10.1594/PANGAEA.824889')
NGRIPdata <- NGRIP[[1]]$data 
colnames(NGRIPdata) <- c("depth", "age", "d18O")
NGRIPdata$calBP <-NGRIPdata$age*1000 
NGRIPdata$calBP <- round(NGRIPdata$calBP, 0)
NGRIPdata <- NGRIPdata %>% filter(calBP>=10000 & calBP<=16000)
NGRIPdata$age <- NULL
# create aoristic chronozone dataframe. 
# create aoristic chronozone dataframe. 
chronozones <- data.frame(row.names=1:8)
chronozones$name <- c("Older Dryas", "Bølling", "Allerød", "Younger Dryas", 
                      "Preboreal", "Early Boreal", "Early Atlantic", "Mid Atlantic")
chronozones$llim <- c(25000, 14650, 13904, 12846, 11653, 10800, 9190, 8090)
chronozones$ulim <- c(14650, 13904, 12846, 11653, 10800, 9190, 8090, 10000)
chronozones$col <- c( "plum", "palegreen3","palegreen4","plum", "palegreen3", "palegreen4", 
                      "chartreuse4", "green4")

#_____________________________________________________________________________

# PARAMETERS 
ncores <- 3 # set the number of processor cores that you want to set to work.
curve <- "intcal20"
normalised <- FALSE # turn of redundant normalisation

# forest calibration
set <- tundra
source("R - 14C paper 3/scripts/calibrate data.R")
tundra.cal <- set.cal




# forest calibration
set <- forest
source("R - 14C paper 3/scripts/calibrate data.R")
forest.cal <- set.cal

# #### KDE

simulations=5000

# 50
bandwidth=50 # bandwidth optimised for sample density? cf Bronk Ramsey
lowerlim=16000
upperlim=10000
#_____________________________________________________________________________
# DATA #####
#_____________________________________________________________________________
# Tundra #####
#____________________________________________________________________________
# KDE
set=tundra
set.cal <- tundra.cal
bins = set$s_bins
message("sampling kernels...")
set.randates = sampleDates(set.cal,
                           bins=NA,
                           nsim=simulations,
                           verbose=FALSE,
                           boot = TRUE)
message("Kernel Density Estimate...")
set.ckde = ckde(set.randates,timeRange=c(lowerlim,upperlim),bw=bandwidth)
tundra.ckde <- set.ckde



#____________________________________________________________________________
# WBD 
tundra.WBD<- WalkerBivarDirichlet(rc_determinations = tundra$c14age,
                                   rc_sigmas = tundra$c14sd,
                                   calibration_curve = intcal20,
                                   n_iter=1e5,
                                   n_thin=5)
tundra.WBD_fit <- PlotPredictiveCalendarAgeDensity(tundra.WBD)



#______________________________________________________________________________
tundra.PP <- PPcalibrate_custom(rc_determinations = tundra$c14age,
                                 rc_sigmas = tundra$c14sd,
                                 labcodes=tundra$labcode,
                                 calibration_curve = intcal20,
                                 calendar_grid_resolution = 1,
                                 n_iter=1e5,
                                 n_thin=10,
                                 show_progress = TRUE)
# extract and append posterior calendar ages to dataset for spatiotemporal plotting
source("R - 14C paper 3/SupplMat scripts/carbondate_function.R")
tundra.calP<- caldates(data=tundra.PP)
tundra <- left_join(x=tundra,
                     y=tundra.calP[, c("labcode", "calBPstart", "calBPend", "calBPmean")],
                     by="labcode")
tundra.PP_fit<- PlotPosteriorMeanRate(tundra.PP)
source("R - 14C paper 3/SupplMat scripts/plotPP edit.R")
tundra.PPCP<- plotPPCP(tundra.PP, n_changes=6, llim=16000, ulim=10000, ActivateLegend = 0)

beep(4)



#_________________________________________________________________________
# forest ####
# KDE
set=forest
set.cal <- forest.cal
bins = set$s_bins
message("sampling kernels...")
set.randates = sampleDates(set.cal,
                           bins=NA,
                           nsim=simulations,
                           verbose=FALSE,
                           boot = TRUE)
message("Kernel Density Estimate...")
set.ckde = ckde(set.randates,timeRange=c(lowerlim,upperlim),bw=bandwidth)
forest.ckde <- set.ckde



#____________________________________________________________________________
# WBD ####
forest.WBD<- WalkerBivarDirichlet(rc_determinations = forest$c14age,
                                  rc_sigmas = forest$c14sd,
                                  calibration_curve = intcal20,
                                  n_iter=1e5,
                                  n_thin=5)
forest.WBD_fit <- PlotPredictiveCalendarAgeDensity(forest.WBD)



#______________________________________________________________________________
forest.PP <- PPcalibrate_custom(rc_determinations = forest$c14age,
                                rc_sigmas = forest$c14sd,
                                labcodes=forest$labcode,
                                calibration_curve = intcal20,
                                calendar_grid_resolution = 1,
                                n_iter=1e5,
                                n_thin=10,
                                show_progress = TRUE)
# extract and append posterior calendar ages to dataset for spatiotemporal plotting
source("R - 14C paper 3/SupplMat scripts/carbondate_function.R")
forest.calP<- caldates(data=forest.PP)
forest <- left_join(x=forest,
                    y=forest.calP[, c("labcode", "calBPstart", "calBPend", "calBPmean")],
                    by="labcode")
forest.PP_fit<- PlotPosteriorMeanRate(forest.PP)
source("R - 14C paper 3/SupplMat scripts/plotPP edit.R")
forest.PPCP<- plotPPCP(forest.PP, n_changes=6, llim=16000, ulim=10000, ActivateLegend = 0)

beep(4)

#______________________________________________________________________________
layout.matrix <- matrix(c(1,2,3,4,5,6,7,8), nrow=4, ncol=2)
layout(mat=layout.matrix)
# layout.show(8)
lowerlim=16000
upperlim=10000
# par(mfrow=c(4,2))
par(oma=c(3,1,1,1))
par(mar=c(2,4.5,4,4.5))
#______________________________________________________________________________
## KDEs ####
#______________________________________________________________________________
plot(tundra.ckde,xaxt="n", xaxs='i',yaxs="i", xlim=c(lowerlim,upperlim))
mtext(paste("Tundra"), side=3, line=3.5, col="black", cex=1, adj=0.1, padj=1)
mtext("a. Composite Kernel Density Estimate", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
phaserect=1
phaselabels=0.1
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)


### tundra WBD ####
#______________________________________________________________________________

plot(x=INTCAL20$BP[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim], 
     y=INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim],
     xlim=rev(range(INTCAL20$BP[INTCAL20$BP<=lowerlim &
                                  INTCAL20$BP>=upperlim])),
     ylim=c(min(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])-2000,
            max(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])+1000),
     type="l", col="royalblue", lwd=2,
     axes= FALSE, xaxs="i",xlab="", ylab="")
axis(4, at=c(10000,12000,14000,16000),labels=TRUE,tck=-0.05,col="black", col.axis="royalblue")
axis(4, at=seq(10000,16000,by=1000), labels=FALSE,tck=-0.03,col="black", col.axis="royalblue")
axis(4, at = tundra$c14age, labels = FALSE, tck=0.02)
mtext(expression(text=''^14*'C age BP'), side=4, line=3, col="royalblue", cex=0.7)
phaserect=1
rm(phaselabels)
par(new=TRUE)
plot(x=tundra.WBD_fit[[1]]$calendar_age_BP,
     y=tundra.WBD_fit[[1]]$density_mean,
     col="purple",
     lwd=2,
     type="l", 
     xaxs="i",
     yaxs="i",
     xlim=c(16000, 10000),
     ylim=c(0,max(tundra.WBD_fit[[1]]$density_ci_upper+
                    (0.2*max(tundra.WBD_fit[[1]]$density_ci_upper)))),
     ylab=NA,
     xlab=NA)
abline(h=0)
mtext("density estimate", side=2, line=3, col="purple", cex=0.7)
mtext("b. Walker Dirichlet Process Mixture Model", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
# text(x= lowerlim, y=par("usr")[4]-(0.1*par("usr")[4]),
#      labels=paste("a. Tundra (Walker); n =", count(tundra)), col="black", cex=1.5, font=2, pos=4)
polygon(x=c(tundra.WBD_fit[[1]]$calendar_age_BP,
            rev(tundra.WBD_fit[[1]]$calendar_age_BP)),
        y=c(tundra.WBD_fit[[1]]$density_ci_upper,
            rev(tundra.WBD_fit[[1]]$density_ci_lower)),
        col=rgb(0.5,0,0.5,0.3), 
        border=NA)
polygon(x=c(tundra.WBD_fit[[1]]$calendar_age_BP,
            rev(tundra.WBD_fit[[1]]$calendar_age_BP)),
        y=c(tundra.WBD_fit[[1]]$density_ci_upper,
            rev(tundra.WBD_fit[[1]]$density_ci_lower)),
        col=NA, 
        border="purple",
        lty=2)
lines(x=tundra.WBD_fit[[1]]$calendar_age_BP,
      y=tundra.WBD_fit[[1]]$density_mean,
      col="purple",
      lwd=2)
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)

box()
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015) 


## POISSON PROCESS ####
#______________________________________________________________________________
### tundra ####
#______________________________________________________________________________
plot(x=INTCAL20$BP[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim], 
     y=INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim],
     xlim=rev(range(INTCAL20$BP[INTCAL20$BP<=lowerlim &
                                  INTCAL20$BP>=upperlim])),
     ylim=c(min(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])-2000,
            max(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])+1000),
     type="l", col="royalblue", lwd=2,
     axes= FALSE, xaxs="i",xlab="", ylab="")
axis(4, at=c(10000,12000,14000,16000),labels=TRUE,tck=-0.05,col="black", col.axis="royalblue")
axis(4, at=seq(1000,16000,by=1000), labels=FALSE,tck=-0.03,col="black", col.axis="royalblue")
axis(4, at = tundra$c14age, labels = FALSE, tck=0.02)
mtext(expression(text=''^14*'C age BP'), side=4, line=3, col="royalblue", cex=0.7)
phaserect=1
rm(phaselabels)

par(new=TRUE)
plot(x=tundra.PP_fit$calendar_age_BP,
     y=tundra.PP_fit$rate_mean,
     col="red",
     lwd=2,
     type="l", 
     xaxs="i",
     xlim=c(16000, 10000),
     ylim=c(0,max(tundra.PP_fit$rate_ci_upper+
                     (0.2*max(tundra.PP_fit$rate_ci_upper)))),
     # ylim=c(0,1.75),
     ylab=NA,
     xlab=NA)
# abline(h=0)
mtext("density estimate", side=2, line=3, col="red", cex=0.7)
mtext("c. Poisson Process", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
polygon(x=c(tundra.PP_fit$calendar_age_BP,
            rev(tundra.PP_fit$calendar_age_BP)),
        y=c(tundra.PP_fit$rate_ci_upper,
            rev(tundra.PP_fit$rate_ci_lower)),
        col=rgb(0.5,0,0,0.3), 
        border=NA)
polygon(x=c(tundra.PP_fit$calendar_age_BP,
            rev(tundra.PP_fit$calendar_age_BP)),
        y=c(tundra.PP_fit$rate_ci_upper,
            rev(tundra.PP_fit$rate_ci_lower)),
        col=NA, 
        border="red",
        lty=2)
lines(x=tundra.PP_fit$calendar_age_BP,
      y=tundra.PP_fit$rate_mean,
      col="red",
      lwd=2)
for(i in 1:length(tundra.PPCP)){
  if(tundra.PPCP[[i]]$n_change==6){
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="orange")}
  if(tundra.PPCP[[i]]$n_change==5){
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="red")}
}
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)
axis(1, at = tundra$calBPmean, labels = FALSE, tck=0.02)
box()
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015)

## POSTERIOR CHANGE POINTS ####
#______________________________________________________________________________

plot(x=c(lowerlim,upperlim), y=c(0,0.005), xlim=c(16000,10000),
     type="n", xaxs="i",yaxs="i",xlab="", ylab="")
source("scripts/phaserect.R")
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015)
mtext(paste("d. Change Points: 5-6 internal changes"), side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
mtext("Probability", side=2, line=3, col="black", cex=0.7)
for(i in 1:length(tundra.PPCP)){
  if(tundra.PPCP[[i]]$n_change==6){
    lines(x=tundra.PPCP[[i]]$x,
          y=tundra.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(1,0,0.6,0.5))
          col="orange")
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="orange")}
  if(tundra.PPCP[[i]]$n_change==5){
    lines(x=tundra.PPCP[[i]]$x,
          y=tundra.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(0.5, 0,0,0.5))
          col="red")
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="red")}
}
box()


#______________________________________________________________________________
lowerlim=16000
upperlim=10000
par(mfrow=c(4,1))
par(oma=c(3,1,1,1))
par(mar=c(2,4.5,4,4.5))

#_____________________________________________________________________________
# forest #####
#____________________________________________________________________________

#______________________________________________________________________________
lowerlim=16000
upperlim=10000
par(mfrow=c(4,1))
par(oma=c(3,1,1,1))
par(mar=c(2,4.5,4,4.5))
#______________________________________________________________________________
## KDEs ####
#______________________________________________________________________________
plot(forest.ckde,xaxt="n", xaxs='i',yaxs="i", xlim=c(lowerlim,upperlim))
mtext(paste("forest"), side=3, line=3.5, col="black", cex=1, adj=0.1, padj=1)
mtext("a. Composite Kernel Density Estimate", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
phaserect=1
phaselabels=0.1
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)


### forest WBD ####
#______________________________________________________________________________

plot(x=INTCAL20$BP[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim], 
     y=INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim],
     xlim=rev(range(INTCAL20$BP[INTCAL20$BP<=lowerlim &
                                  INTCAL20$BP>=upperlim])),
     ylim=c(min(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])-2000,
            max(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])+1000),
     type="l", col="royalblue", lwd=2,
     axes= FALSE, xaxs="i",xlab="", ylab="")
axis(4, at=c(10000,12000,14000,16000),labels=TRUE,tck=-0.05,col="black", col.axis="royalblue")
axis(4, at=seq(10000,16000,by=1000), labels=FALSE,tck=-0.03,col="black", col.axis="royalblue")
axis(4, at = forest$c14age, labels = FALSE, tck=0.02)
mtext(expression(text=''^14*'C age BP'), side=4, line=3, col="royalblue", cex=0.7)
phaserect=1
rm(phaselabels)
par(new=TRUE)
plot(x=forest.WBD_fit[[1]]$calendar_age_BP,
     y=forest.WBD_fit[[1]]$density_mean,
     col="purple",
     lwd=2,
     type="l", 
     xaxs="i",
     yaxs="i",
     xlim=c(16000, 10000),
     ylim=c(0,max(forest.WBD_fit[[1]]$density_ci_upper+
                    (0.2*max(forest.WBD_fit[[1]]$density_ci_upper)))),
     ylab=NA,
     xlab=NA)
abline(h=0)
mtext("density estimate", side=2, line=3, col="purple", cex=0.7)
mtext("b. Walker Dirichlet Process Mixture Model", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
# text(x= lowerlim, y=par("usr")[4]-(0.1*par("usr")[4]),
#      labels=paste("a. forest (Walker); n =", count(forest)), col="black", cex=1.5, font=2, pos=4)
polygon(x=c(forest.WBD_fit[[1]]$calendar_age_BP,
            rev(forest.WBD_fit[[1]]$calendar_age_BP)),
        y=c(forest.WBD_fit[[1]]$density_ci_upper,
            rev(forest.WBD_fit[[1]]$density_ci_lower)),
        col=rgb(0.5,0,0.5,0.3), 
        border=NA)
polygon(x=c(forest.WBD_fit[[1]]$calendar_age_BP,
            rev(forest.WBD_fit[[1]]$calendar_age_BP)),
        y=c(forest.WBD_fit[[1]]$density_ci_upper,
            rev(forest.WBD_fit[[1]]$density_ci_lower)),
        col=NA, 
        border="purple",
        lty=2)
lines(x=forest.WBD_fit[[1]]$calendar_age_BP,
      y=forest.WBD_fit[[1]]$density_mean,
      col="purple",
      lwd=2)
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)

box()
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015) 


## POISSON PROCESS ####
#______________________________________________________________________________
### forest ####
#______________________________________________________________________________
plot(x=INTCAL20$BP[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim], 
     y=INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim],
     xlim=rev(range(INTCAL20$BP[INTCAL20$BP<=lowerlim &
                                  INTCAL20$BP>=upperlim])),
     ylim=c(min(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])-2000,
            max(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])+1000),
     type="l", col="royalblue", lwd=2,
     axes= FALSE, xaxs="i",xlab="", ylab="")
axis(4, at=c(10000,12000,14000,16000),labels=TRUE,tck=-0.05,col="black", col.axis="royalblue")
axis(4, at=seq(1000,16000,by=1000), labels=FALSE,tck=-0.03,col="black", col.axis="royalblue")
axis(4, at = forest$c14age, labels = FALSE, tck=0.02)
mtext(expression(text=''^14*'C age BP'), side=4, line=3, col="royalblue", cex=0.7)
phaserect=1
rm(phaselabels)

par(new=TRUE)
plot(x=forest.PP_fit$calendar_age_BP,
     y=forest.PP_fit$rate_mean,
     col="red",
     lwd=2,
     type="l", 
     xaxs="i",
     xlim=c(16000, 10000),
     ylim=c(0,max(forest.PP_fit$rate_ci_upper+
                    (0.2*max(forest.PP_fit$rate_ci_upper)))),
     # ylim=c(0,1.75),
     ylab=NA,
     xlab=NA)
# abline(h=0)
mtext("density estimate", side=2, line=3, col="red", cex=0.7)
mtext("c. Poisson Process", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
polygon(x=c(forest.PP_fit$calendar_age_BP,
            rev(forest.PP_fit$calendar_age_BP)),
        y=c(forest.PP_fit$rate_ci_upper,
            rev(forest.PP_fit$rate_ci_lower)),
        col=rgb(0.5,0,0,0.3), 
        border=NA)
polygon(x=c(forest.PP_fit$calendar_age_BP,
            rev(forest.PP_fit$calendar_age_BP)),
        y=c(forest.PP_fit$rate_ci_upper,
            rev(forest.PP_fit$rate_ci_lower)),
        col=NA, 
        border="red",
        lty=2)
lines(x=forest.PP_fit$calendar_age_BP,
      y=forest.PP_fit$rate_mean,
      col="red",
      lwd=2)
for(i in 1:length(forest.PPCP)){
  if(forest.PPCP[[i]]$n_change==6){
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="orange")}
  if(forest.PPCP[[i]]$n_change==5){
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="red")}
}
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)
axis(1, at = forest$calBPmean.x, labels = FALSE, tck=0.02)
box()
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015)

## POSTERIOR CHANGE POINTS ####
#______________________________________________________________________________

plot(x=c(lowerlim,upperlim), y=c(0,0.005), xlim=c(16000,10000),
     type="n", xaxs="i",yaxs="i",xlab="", ylab="")
source("scripts/phaserect.R")
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015)
mtext(paste("d. Change Points: 5-6 internal changes"), side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
mtext("Probability", side=2, line=3, col="black", cex=0.7)
for(i in 1:length(forest.PPCP)){
  if(forest.PPCP[[i]]$n_change==6){
    lines(x=forest.PPCP[[i]]$x,
          y=forest.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(1,0,0.6,0.5))
          col="orange")
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="orange")}
  if(forest.PPCP[[i]]$n_change==5){
    lines(x=forest.PPCP[[i]]$x,
          y=forest.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(0.5, 0,0,0.5))
          col="red")
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="red")}
}
box()
beep(4)



path <- "R - Discussion/data/forestcal.xlsx"
write.xlsx(forest, file=path)
path <- "R - Discussion/data/tundracal.xlsx"
write.xlsx(tundra, file=path)
