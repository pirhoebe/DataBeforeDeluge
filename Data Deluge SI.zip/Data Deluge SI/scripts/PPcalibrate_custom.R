PPcalibrate_custom <- function (rc_determinations, rc_sigmas, calibration_curve, labcodes, F14C_inputs = FALSE, 
          n_iter = 1e+05, n_thin = 10, use_F14C_space = TRUE, show_progress = TRUE, 
          calendar_age_range = NA, calendar_grid_resolution = 1, prior_h_shape = NA, 
          prior_h_rate = NA, prior_n_internal_changepoints_lambda = 3, 
          k_max_internal_changepoints = 30, rescale_factor_rev_jump = 0.9, 
          bounding_range_prob_cutoff = 0.001, initial_n_internal_changepoints = 10, 
          grid_extension_factor = 0.1, use_fast = TRUE, fast_approx_prob_cutoff = 0.001) 
{
  arg_check <- carbondate:::.InitializeErrorList()
  carbondate:::.CheckInputData(arg_check, rc_determinations, rc_sigmas, 
                  F14C_inputs)
  carbondate:::.CheckCalibrationCurve(arg_check, calibration_curve, NA)
  carbondate:::.CheckIterationParameters(arg_check, n_iter, n_thin)
  carbondate:::.CheckFlag(arg_check, F14C_inputs)
  carbondate:::.CheckFlag(arg_check, use_F14C_space)
  carbondate:::.CheckFlag(arg_check, show_progress)
  if (!any(is.na(calendar_age_range))) {
    carbondate:::.CheckNumberVector(arg_check, calendar_age_range, len = 2)
  }
  carbondate:::.CheckNumber(arg_check, calendar_grid_resolution, lower = 0)
  carbondate:::.CheckPriorHShapeAndPriorHRate(arg_check, prior_h_shape, 
                                 prior_h_rate)
  carbondate:::.CheckInteger(arg_check, k_max_internal_changepoints, lower = 1)
  carbondate:::.CheckNumber(arg_check, bounding_range_prob_cutoff, lower = 0, 
               upper = 0.01)
  carbondate:::.CheckInteger(arg_check, initial_n_internal_changepoints, 
                upper = k_max_internal_changepoints - 1)
  carbondate:::.CheckNumber(arg_check, grid_extension_factor, lower = 0)
  carbondate:::.CheckFlag(arg_check, use_fast)
  carbondate:::.CheckNumber(arg_check, fast_approx_prob_cutoff, lower = 0, 
               upper = 0.01)
  carbondate:::.ReportErrors(arg_check)
  input_data <- list(rc_determinations = rc_determinations, 
                     rc_sigmas = rc_sigmas, 
                     labcodes=labcodes,
                     F14C_inputs = F14C_inputs, calibration_curve_name = deparse(substitute(calibration_curve)))
  if (F14C_inputs == use_F14C_space) {
    rc_determinations <- as.double(rc_determinations)
    rc_sigmas <- as.double(rc_sigmas)
  }
  else if (F14C_inputs == FALSE) {
    converted <- carbondate:::.Convert14CageToF14c(rc_determinations, 
                                      rc_sigmas)
    rc_determinations <- converted$f14c
    rc_sigmas <- converted$f14c_sig
  }
  else {
    converted <- carbondate:::.ConvertF14cTo14Cage(rc_determinations, 
                                      rc_sigmas)
    rc_determinations <- converted$c14_age
    rc_sigmas <- converted$c14_sig
  }
  bounds_calendar_range <- carbondate:::.FindBoundingCalendarRange(rc_determinations = rc_determinations, 
                                                      rc_sigmas = rc_sigmas, calibration_curve = calibration_curve, 
                                                      F14C_inputs = use_F14C_space, prob_cutoff = bounding_range_prob_cutoff)
  if (any(is.na(calendar_age_range))) {
    min_potential_calendar_age <- min(bounds_calendar_range)
    max_potential_calendar_age <- max(bounds_calendar_range)
    mean_potential_calendar_age <- mean(bounds_calendar_range)
    min_potential_calendar_age <- (min_potential_calendar_age - 
                                     grid_extension_factor * (mean_potential_calendar_age - 
                                                                min_potential_calendar_age))
    max_potential_calendar_age <- (max_potential_calendar_age + 
                                     grid_extension_factor * (max_potential_calendar_age - 
                                                                mean_potential_calendar_age))
    min_potential_calendar_age <- (floor(min_potential_calendar_age/calendar_grid_resolution) * 
                                     calendar_grid_resolution)
    max_potential_calendar_age <- (ceiling(max_potential_calendar_age/calendar_grid_resolution) * 
                                     calendar_grid_resolution)
    min_potential_calendar_age <- max(min_potential_calendar_age, 
                                      min(calibration_curve$calendar_age_BP))
    max_potential_calendar_age <- min(max_potential_calendar_age, 
                                      max(calibration_curve$calendar_age_BP))
  }
  else {
    min_potential_calendar_age <- min(calendar_age_range)
    max_potential_calendar_age <- max(calendar_age_range)
    if (min_potential_calendar_age > min(bounds_calendar_range)) {
      warning("The minimum of your selected calendar age range may not cover the age range of the samples. Consider reducing the minimum age range.", 
              immediate. = TRUE)
    }
    if (max_potential_calendar_age < max(bounds_calendar_range)) {
      warning("The maximum of your selected calendar age range may not cover the age range of the samples. COnsider increasing the maximum age range.", 
              immediate. = TRUE)
    }
  }
  calendar_age_grid <- seq(min_potential_calendar_age, max_potential_calendar_age, 
                           by = calendar_grid_resolution)
  if ((max(calendar_age_grid) != max_potential_calendar_age)) {
    if (!any(is.na(calendar_age_range))) {
      warning("Extending calendar age range for Poisson Process as selected grid resolution doesn't divide age range.", 
              immediate. = TRUE)
    }
    max_potential_calendar_age <- (calendar_age_grid[length(calendar_age_grid)] + 
                                     calendar_grid_resolution)
    cc <- c(calendar_age_grid, max_potential_calendar_age)
  }
  calendar_age_interval_length <- max_potential_calendar_age - 
    min_potential_calendar_age
  n_determinations <- length(rc_determinations)
  initial_estimate_mean_rate <- n_determinations/calendar_age_interval_length
  if (is.na(prior_h_shape)) {
    prior_h_shape <- 1
    prior_h_rate <- 1/initial_estimate_mean_rate
  }
  initial_rate_s <- sort(c(min_potential_calendar_age, stats::runif(initial_n_internal_changepoints, 
                                                                    min = min_potential_calendar_age, max = max_potential_calendar_age), 
                           max_potential_calendar_age))
  initial_rate_h <- rep(initial_estimate_mean_rate, times = initial_n_internal_changepoints + 
                          1)
  initial_rate_h_log_multiplier <- stats::runif(n = initial_n_internal_changepoints + 
                                                  1, min = -1, max = 1)
  initial_rate_h <- exp(initial_rate_h_log_multiplier) * initial_rate_h
  initial_integrated_rate <- carbondate:::.FindIntegral(rate_s = initial_rate_s, 
                                           rate_h = initial_rate_h)
  input_parameters <- list(pp_cal_age_range = c(min_potential_calendar_age, 
                                                max_potential_calendar_age), prior_n_internal_changepoints_lambda = prior_n_internal_changepoints_lambda, 
                           k_max_internal_changepoints = k_max_internal_changepoints, 
                           prior_h_shape = prior_h_shape, prior_h_rate = prior_h_rate, 
                           rescale_factor_rev_jump = rescale_factor_rev_jump, calendar_age_grid = calendar_age_grid, 
                           calendar_grid_resolution = calendar_grid_resolution, 
                           n_iter = n_iter, n_thin = n_thin)
  likelihood_calendar_ages_from_calibration_curve <- mapply(carbondate:::.CalendarAgeLikelihoodGivenCurve, 
                                                            rc_determinations, rc_sigmas, MoreArgs = list(theta = calendar_age_grid, 
                                                                                                          F14C_inputs = use_F14C_space, calibration_curve = calibration_curve))
  if (use_fast) {
    likelihood_values <- list()
    likelihood_offsets <- c()
    for (i in 1:dim(likelihood_calendar_ages_from_calibration_curve)[2]) {
      ret <- carbondate:::.FindTrimmedVectorAndIndices(likelihood_calendar_ages_from_calibration_curve[, 
                                                                                          i], fast_approx_prob_cutoff)
      likelihood_values[[i]] <- ret$values
      likelihood_offsets[i] <- as.integer(ret$offset - 
                                            1)
    }
  }
  else {
    likelihood_values <- NA
    likelihood_offsets <- NA
  }
  num_observations <- length(rc_determinations)
  rate_s <- initial_rate_s
  rate_h <- initial_rate_h
  integrated_rate <- initial_integrated_rate
  prob_move <- carbondate:::.FindMoveProbability(prior_n_internal_changepoints_lambda = prior_n_internal_changepoints_lambda, 
                                    k_max_internal_changepoints = k_max_internal_changepoints, 
                                    rescale_factor = rescale_factor_rev_jump)
  n_out <- floor(n_iter/n_thin) + 1
  rate_s_out <- list(rate_s)
  rate_h_out <- list(rate_h)
  n_internal_changes <- rep(NA, length = n_out)
  theta_out <- matrix(NA, nrow = n_out, ncol = num_observations)
  output_index <- 1
  n_internal_changes[output_index] <- length(rate_h) - 1
  calendar_ages <- carbondate:::.UpdateCalendarAges(likelihood_calendar_ages_from_calibration_curve, 
                                       likelihood_values, likelihood_offsets, calendar_age_grid, 
                                       rate_s, rate_h, use_fast)
  theta_out[output_index, ] <- calendar_ages
  if (show_progress) {
    progress_bar <- utils::txtProgressBar(min = 0, max = n_iter, 
                                          style = 3)
  }
  for (iter in 1:n_iter) {
    calendar_ages <- carbondate:::.UpdateCalendarAges(likelihood_calendar_ages_from_calibration_curve, 
                                         likelihood_values, likelihood_offsets, calendar_age_grid, 
                                         rate_s, rate_h, use_fast)
    updated_poisson_process <- carbondate:::.UpdatePoissonProcessRateRevJump(theta = calendar_ages, 
                                                                rate_s = rate_s, rate_h = rate_h, integrated_rate = integrated_rate, 
                                                                prior_h_shape = prior_h_shape, prior_h_rate = prior_h_rate, 
                                                                prior_n_internal_changepoints_lambda = prior_n_internal_changepoints_lambda, 
                                                                prob_move = prob_move)
    rate_s <- updated_poisson_process$rate_s
    rate_h <- updated_poisson_process$rate_h
    integrated_rate <- updated_poisson_process$integrated_rate
    if (iter%%n_thin == 0) {
      output_index <- output_index + 1
      n_internal_changes[output_index] <- length(rate_h) - 
        1
      rate_h_out[[output_index]] <- rate_h
      rate_s_out[[output_index]] <- rate_s
      theta_out[output_index, ] <- calendar_ages
    }
    if (show_progress) {
      if (iter%%100 == 0) {
        utils::setTxtProgressBar(progress_bar, iter)
      }
    }
  }
  return_list <- list(rate_s = rate_s_out, rate_h = rate_h_out, 
                      calendar_ages = theta_out, n_internal_changes = n_internal_changes, 
                      update_type = "RJPP", input_data = input_data, input_parameters = input_parameters)
  if (show_progress) 
    close(progress_bar)
  return(return_list)
}
