###############################################################################
#### calibration ####
###############################################################################

message("calibrating dataset...")
set$c14age <- as.numeric(set$c14age)
set <- filter(set, !is.na(set$c14age))
set <- filter(set, !is.na(set$c14sd))
if("site_id" %in% colnames(set))
{set <- filter(set, !is.na(set$site_id))}


set.cal=calibrate(
  x=set$c14age,
  errors=set$c14sd,
  dateDetails=set$sitename, 
  calCurves=curve,
  normalised=normalised, 
  ncores=ncores)
message("calibrating done!")
set.cal$metadata$country <- set$country


###############################################################################
# check for missing columns
xcolumn <- "labcode"
if(xcolumn %in% colnames(set)){
  set.cal$metadata$labcode <- set$labcode
}else{
  message(paste(xcolumn, "column is not present in dataset, 
    so this information will not be present after calibration"))
}
rm(xcolumn)

xcolumn <- "vet"
if(xcolumn %in% colnames(set)){
  set.cal$metadata$vet <- set$vet
}else{
  message(paste(xcolumn, "column is not present in dataset, 
    so this information will not be present after calibration"))
}
rm(xcolumn)

xcolumn <- "region"
if(xcolumn %in% colnames(set)){
  set.cal$metadata$region <- set$region
}else{
    message(paste(xcolumn, "column is not present in dataset, 
    so this information will not be present after calibration"))
}
xcolumn <- "site_id"
if(xcolumn %in% colnames(set)){
  set.cal$metadata$site_id <- set$site_id
}else{
  message(paste(xcolumn, "column is not present in dataset, 
    so this information will not be present after calibration"))
}
rm(xcolumn)