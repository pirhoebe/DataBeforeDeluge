library(readxl)
library(dplyr)
library(ggplot2)
library(openxlsx)
library(tidyr)
# archis <- read_excel("ARCHIS PaleoMeso.xlsx")
archis <- read_excel("ARCHIS PM 2.0.xlsx")

archis <- unique(archis)
periodenummering <- read_excel("periodenummering.xlsx")

archis <- archis%>%rename(beginperiode=beginperiode_label,
                          eindperiode=eindperiode_label,
                          materiaal=materiaal_label,
                          cultuur=cultuur_label,
                          type=type_label)


archis$beginperiode[archis$cultuur %in% c("Ahrensburg-cultuur",
                                          "Creswell-cultuur",
                                          "Hamburg-cultuur",
                                          "Magdalenien-cultuur",
                                          "Tjonger-cultuur")] <- "Laat Paleolithicum B"
archis$eindperiode[archis$cultuur %in% c("Ahrensburg-cultuur",
                                          "Creswell-cultuur",
                                          "Hamburg-cultuur",
                                          "Magdalenien-cultuur",
                                          "Tjonger-cultuur")] <- "Laat Paleolithicum B"
archis$beginperiode[archis$cultuur %in% c("Rhine basin-kreis",
                                          "Northwest-kreis")] <- "Midden Mesolithicum"
archis$eindperiode[archis$cultuur %in% c("Rhine basin-kreis",
                                          "Northwest-kreis")] <- "Midden Mesolithicum"
archis$beginperiode[archis$cultuur %in% c("Late mesolithic survival",
                                          "De leijen-wartena complex" )] <- "Laat Mesolithicum"
archis$eindperiode[archis$cultuur %in% c("Late mesolithic survival",
                                          "De leijen-wartena complex" )] <- "Laat Mesolithicum"
archis$beginperiode[archis$cultuur %in% c("Swifterbant-cultuur")] <- "Laat Mesolithicum"
archis$eindperiode[archis$cultuur %in% c("Swifterbant-cultuur")] <- "Vroeg Neolithicum"

levels(as.factor(archis$beginperiode_code))
archis$beginperiode_code[archis$beginperiode=="Laat Paleolithicum B"] <- "PALEOLB"
archis$eindperiode_code[archis$eindperiode=="Laat Paleolithicum B"] <- "PALEOLB"
archis$beginperiode_code[archis$beginperiode=="Midden Mesolithicum"] <- "MESOM"
archis$eindperiode_code[archis$eindperiode=="Midden Mesolithicum"] <- "MESOM"
archis$beginperiode_code[archis$beginperiode=="Laat Mesolithicum"] <- "MESOL"
archis$eindperiode_code[archis$eindperiode=="Laat Mesolithicum"] <- "MESOL"
archis$eindperiode_code[archis$eindperiode=="Vroeg Neolithicum"] <- "NEOV"
archis$periode_range <- paste(archis$beginperiode_code, "-", archis$eindperiode_code)

archis <- archis%>%filter(beginperiode_code %in% c("PALEO", "PALEOLB", "PALEOLA", "PALEOL", "MESO",
                                                   "MESOV", "MESOM", "MESOL"))
archis <- archis%>%filter(eindperiode_code %in% c("PALEO","PALEOLB", "PALEOLA", "PALEOL", "MESO",
                                                   "MESOV", "MESOM", "MESOL", "NEOV"))
for( i in periodenummering$periode){
  periodenummer <- periodenummering$nummerring[periodenummering$periode==i]
  archis$periode_Nstart[archis$beginperiode==i] <- periodenummer
  archis$periode_Neind[archis$eindperiode==i] <- periodenummer
}
archis$periode_zekerheid <- NA

levels(as.factor(archis$beginperiode_code))



pfreq_archis <- archis%>%
  group_by(periode_range, periode_Nstart, periode_Neind)%>%
  count(periode_range)

archis_find <- archis%>%filter(object_type== "vondst")
pfreq_find <- archis_find%>%
  group_by(periode_range)%>%
  count(periode_range)
archis_find <- archis%>%filter(object_type== "complex")
pfreq_complex <- archis_complex%>%
  group_by(periode_range)%>%
  count(periode_range)
archis_find <- archis%>%filter(object_type== "grondspoor")
pfreq_feature <- archis_feature%>%
  group_by(periode_range)%>%
  count(periode_range)


pfreq_archis_total <- left_join(pfreq_archis, pfreq_find, by="periode_range")
pfreq_archis_total <- left_join(pfreq_archis_total, pfreq_feature, by="periode_range")
pfreq_archis_total <- left_join(pfreq_archis_total, pfreq_complex, by="periode_range")
pfreq_archis_total <- pfreq_archis_total%>%rename(archis=n.x,
                                      find=n.y,
                                      feature=n.x.x,
                                      complex=n.y.y)

write.xlsx(pfreq_archis_total, file="pfreq_archis.xlsx")
periodeselect <- read_excel("period selection.xlsx")
pselect <- periodeselect%>% select(periode_range, select, precision)

archis <- left_join(archis, pselect, by = "periode_range")
archis <- unique(archis)

archis_PM <- archis%>%filter(select==1)

archis_rest <- archis%>%filter(select==0)


archis_PM$beginperiode_code[archis_PM$beginperiode_code=="PALEOLA"] <- "PALEOL"
archis_PM$beginperiode_code[archis_PM$beginperiode_code=="PALEOLB"] <- "PALEOL"
archis_PM$eindperiode_code[archis_PM$eindperiode_code=="PALEOLA"] <- "PALEOL"
archis_PM$eindperiode_code[archis_PM$eindperiode_code=="PALEOLB"] <- "PALEOL"
archis_PM$eindperiode_code[archis_PM$eindperiode_code=="NEOVA"] <- "NEOV"
archis_PM$eindperiode_code[archis_PM$eindperiode_code=="NEOVB"] <- "NEOV"

archis_PM$periode_Nstart <- round(archis_PM$periode_Nstart, 1)
archis_PM$periode_Neind <- round(archis_PM$periode_Neind, 1)




# hier aoristiek toepassen?

archis_PM$paleol <- NA
archis_PM$mesov <- NA
archis_PM$mesom <- NA
archis_PM$mesol <- NA
archis_PM$neov <- NA
levels(as.factor(archis_PM$periode_Neind))
archis_PM$beginperiode[archis_PM$beginperiode%in%c("Laat Paleolithicum A",
                                                   "Laat Paleolithicum B")] <- "Laat Paleolithicum"
archis_PM$eindperiode[archis_PM$eindperiode%in%c("Laat Paleolithicum A",
                                                   "Laat Paleolithicum B")] <- "Laat Paleolithicum"
archis_PM$eindperiode[archis_PM$eindperiode%in%c("Vroeg Neolithicum A",
                                                 "Vroeg Neolithicum B")] <- "Vroeg Neolithicum"
archis_PM$periode_range=paste(archis_PM$beginperiode_code,"-", archis_PM$eindperiode_code)
archis_PM$paleol[archis_PM$periode_range%in%c("PALEOL - PALEOL")] <- 1
archis_PM$paleol[archis_PM$periode_range%in%c("PALEOL - MESOV")] <- 0.5
archis_PM$mesov[archis_PM$periode_range%in%c("PALEOL - MESOV")] <- 0.5

archis_PM$paleol[archis_PM$periode_range%in%c("PALEOL - MESOM")] <- 1/3
archis_PM$mesov[archis_PM$periode_range%in%c("PALEOL - MESOM")] <- 1/3
archis_PM$mesom[archis_PM$periode_range%in%c("PALEOL - MESOM")] <- 1/3

archis_PM$paleol[archis_PM$periode_range%in%c("PALEOL - MESOL")] <- 0.25
archis_PM$mesov[archis_PM$periode_range%in%c("PALEOL - MESOL")] <- 0.25
archis_PM$mesom[archis_PM$periode_range%in%c("PALEOL - MESOL")] <- 0.25
archis_PM$mesol[archis_PM$periode_range%in%c("PALEOL - MESOL")] <- 0.25

archis_PM$paleol[archis_PM$periode_range%in%c("PALEOL - MESO")] <- 0.25
archis_PM$mesov[archis_PM$periode_range%in%c("PALEOL - MESO")] <- 0.25
archis_PM$mesom[archis_PM$periode_range%in%c("PALEOL - MESO")] <- 0.25
archis_PM$mesol[archis_PM$periode_range%in%c("PALEOL - MESO")] <- 0.25

archis_PM$mesov[archis_PM$periode_range%in%c("MESO - MESO")] <- 1/3
archis_PM$mesom[archis_PM$periode_range%in%c("MESO - MESO")] <- 1/3
archis_PM$mesol[archis_PM$periode_range%in%c("MESO - MESO")] <- 1/3

archis_PM$mesov[archis_PM$periode_range%in%c("MESO - MESOL")] <- 1/3
archis_PM$mesom[archis_PM$periode_range%in%c("MESO - MESOL")] <- 1/3
archis_PM$mesol[archis_PM$periode_range%in%c("MESO - MESOL")] <- 1/3

archis_PM$mesov[archis_PM$periode_range%in%c("MESO - MESOV")] <- 1

archis_PM$mesov[archis_PM$periode_range%in%c( "MESO - NEOV")] <- 0.25
archis_PM$mesom[archis_PM$periode_range%in%c( "MESO - NEOV")] <- 0.25
archis_PM$mesol[archis_PM$periode_range%in%c( "MESO - NEOV")] <- 0.25
archis_PM$neov[archis_PM$periode_range%in%c( "MESO - NEOV")] <- 0.25

archis_PM$mesov[archis_PM$periode_range%in%c( "MESOV - NEOV")] <- 0.25
archis_PM$mesom[archis_PM$periode_range%in%c( "MESOV - NEOV")] <- 0.25
archis_PM$mesol[archis_PM$periode_range%in%c( "MESOV - NEOV")] <- 0.25
archis_PM$neov[archis_PM$periode_range%in%c( "MESOV - NEOV")] <- 0.25

archis_PM$mesol[archis_PM$periode_range%in%c("MESOL - MESOL")] <- 1
archis_PM$mesom[archis_PM$periode_range%in%c("MESOM - MESOM")] <- 1
archis_PM$mesov[archis_PM$periode_range%in%c("MESOV - MESOV")] <- 1

archis_PM$mesol[archis_PM$periode_range%in%c("MESOL - MESOM")] <- 0.5
archis_PM$mesom[archis_PM$periode_range%in%c("MESOL - MESOM")] <- 0.5

archis_PM$mesol[archis_PM$periode_range%in%c("MESOM - MESOL")] <- 0.5
archis_PM$mesom[archis_PM$periode_range%in%c("MESOM - MESOL")] <- 0.5

archis_PM$mesom[archis_PM$periode_range%in%c(  "MESOM - NEOV" )] <- 1/3
archis_PM$mesol[archis_PM$periode_range%in%c( "MESOM - NEOV")] <- 1/3
archis_PM$neov[archis_PM$periode_range%in%c( "MESOM - NEOV")] <- 1/3

archis_PM$mesol[archis_PM$periode_range%in%c( "MESOL - NEOV")] <- 0.5
archis_PM$neov[archis_PM$periode_range%in%c( "MESOL - NEOV")] <- 0.5

archis_PM$mesov[archis_PM$periode_range%in%c("MESOV - MESO")] <- 1/3
archis_PM$mesom[archis_PM$periode_range%in%c("MESOV - MESO")] <- 1/3
archis_PM$mesol[archis_PM$periode_range%in%c("MESOV - MESO")] <- 1/3

archis_PM$mesov[archis_PM$periode_range%in%c("MESOV - MESOL")] <- 1/3
archis_PM$mesom[archis_PM$periode_range%in%c("MESOV - MESOL")] <- 1/3
archis_PM$mesol[archis_PM$periode_range%in%c("MESOV - MESOL")] <- 1/3

archis_PM$mesov[archis_PM$periode_range%in%c("MESOV - MESOM")] <- 0.5
archis_PM$mesom[archis_PM$periode_range%in%c("MESOV - MESOM")] <- 0.5

archis_PM$paleol[is.na(archis_PM$paleol)] <- 0
archis_PM$mesov[is.na(archis_PM$mesov)] <- 0
archis_PM$mesom[is.na(archis_PM$mesom)] <- 0
archis_PM$mesol[is.na(archis_PM$mesol)] <- 0
archis_PM$neov[is.na(archis_PM$neov)] <- 0

archis_PM$psum=archis_PM$paleol+
  archis_PM$mesov+
  archis_PM$mesom+
  archis_PM$mesol+
  archis_PM$neov


write.xlsx(archis_PM, file="archis_PM.xlsx")
archis_PM <- read_excel("archis_PM.xlsx", sheet=1)
# select verwerving
archis_PM$acquisition <- NA_character_
levels(as.factor(archis_PM$Verwervingswijze))
archis_PM$acquisition[archis_PM$Verwervingswijze == "Veldkartering" &
                        archis_PM$`Soort verwerving` == "Archeologisch" ] <- "Survey (systematic)"
archis_PM$acquisition[archis_PM$Verwervingswijze == "Veldkartering" &
                        archis_PM$`Soort verwerving` == "Niet Archeologisch" ] <- "Survey (not systematic)"
archis_PM$acquisition[archis_PM$Verwervingswijze %in% c("Inspectie",
                                                        "Archief",
                                                        "Collectiebeschrijving",
                                                        "Baggerwerk",
                                                        "Graafwerk",
                                                        "Metaaldetectie",
                                                        "Waterwerk en Exploitatie") ] <- "Survey (not systematic)"
archis_PM$acquisition[archis_PM$Verwervingswijze =="Boring"] <-"Coring" 
archis_PM$acquisition[archis_PM$Verwervingswijze %in% c("Begeleiding",
                                                        "Proefsleuven/putten")] <-"Prospection" 
archis_PM$acquisition[archis_PM$Verwervingswijze =="Opgraving"] <-"Excavation" 
archis_PM$acquisition[archis_PM$Verwervingswijze %in% c("Bureauonderzoek",
                                                        "Verwachtingskaart",
                                                        "Literatuur",
                                                        "Niet te Bepalen")] <- "Indet"

archis_PM$X_WGS.x <- NULL
archis <- read_excel("ARCHIS 21-5/archis_coordinates.xlsx")
archis_loc <- archis%>%select(object_nummer=object_n_1, X_RD, Y_RD, X_WGS=X_wgs, Y_WGS)
archis_PM <- left_join(archis_PM, archis_loc, by="object_nummer")

write.xlsx(archis_PM, file="archis_PM (final).xlsx")
archis_PM <- read_excel("archis_PM (final).xlsx")

archis_PMlist() 


archis_acquisition <- levels(as.factor(archis_PM$acquisition))
archis_list <- NULL
for (i in 1:length(archis_acquisition)){
  sel_complex <- archis_PM %>% filter(acquisition==archis_acquisition[i] & object_type == "complex")
  write.xlsx(sel_complex, file=paste("archis",archis_acquisition[i], "complex.xlsx"))
  sel_feature <- archis_PM %>% filter(acquisition==archis_acquisition[i] & object_type == "grondspoor")
  write.xlsx(sel_complex, file=paste("archis",archis_acquisition[i], "feature.xlsx"))
  sel_find <- archis_PM %>% filter(acquisition==archis_acquisition[i] & object_type == "vondst")
  write.xlsx(sel_complex, file=paste("archis",archis_acquisition[i], "find.xlsx"))
  archis_list[[archis_acquisition[i]]]$complex <- sel_complex
  archis_list[[archis_acquisition[i]]]$feature <- sel_feature
  archis_list[[archis_acquisition[i]]]$find <- sel_find
}


archis_complex <- archis_PM %>% filter(object_type=="complex")
archis_complex <- archis_complex%>%filter(Verwervingswijze%in%c())

archis_feature <- archis_PM %>% filter(object_type=="grondspoor")
archis_find <- archis_PM %>% filter(object_type=="vondst")


archis_periods <- archis_PM%>%select(acquisition, object_type, paleol, mesov, mesom, mesol, neov)
aor_archis <- archis_periods%>% group_by(acquisition, object_type)%>%
  summarise(across(everything(), sum))
count_archis <- archis_periods%>% group_by(acquisition, object_type)%>%count(object_type)
aor_archis$period <- factor(aor_archis$period, levels=aor_archis$period)
################################################################################
#PLOTS
################################################################################
##### 1 Survey (not systematic)####
aor_survey_ns <- aor_archis%>% filter(acquisition =="Survey (not systematic)")
aor_survey_ns$acquisition <- NULL
aor_survey_ns<- aor_survey_ns%>%
  pivot_longer(cols=c(-object_type), names_to="period")%>%pivot_wider(names_from=object_type)
aor_survey_ns$period <- factor(aor_survey_ns$period, levels=aor_survey_ns$period)
par(mfrow=c(3,1))
par(mar=c(4,5,4,2))
## finds
bar_survey_ns_fi <- barplot(aor_survey_ns$vondst, 
                        names.arg = aor_survey_ns$period,
                        ylab="aoristic weight",
                        ylim=c(0,max(aor_survey_ns$vondst)+(0.2*max(aor_survey_ns$vondst))),
                        main="Finds - Survey (not systematic)")
text(bar_survey_ns_fi,
     aor_survey_ns$vondst+(0.1*max(aor_survey_ns$vondst)),
     round(aor_survey_ns$vondst,1))
## features
bar_survey_ns_ft <- barplot(aor_survey_ns$grondspoor, 
                         names.arg = aor_survey_ns$period,
                         ylab="aoristic weight",
                         ylim=c(0,max(aor_survey_ns$grondspoor)+(0.2*max(aor_survey_ns$grondspoor))),
                         main="Features - Survey (not systematic)")
text(bar_survey_ns_ft,
     aor_survey_ns$grondspoor+(0.1*max(aor_survey_ns$grondspoor)),
     round(aor_survey_ns$grondspoor,1))
## complexes
bar_survey_ns_cx <- barplot(aor_survey_ns$complex, 
                            names.arg = aor_survey_ns$period,
                            ylab="aoristic weight",
                            ylim=c(0,max(aor_survey_ns$complex)+(0.2*max(aor_survey_ns$complex))),
                            main="Complexes - Survey (not systematic)")
text(bar_survey_ns_cx,
     aor_survey_ns$complex+(0.1*max(aor_survey_ns$complex)),
     round(aor_survey_ns$complex,1))


##### 2 Survey (systematic)####
aor_survey_s <- aor_archis%>% filter(acquisition =="Survey (systematic)")
aor_survey_s$acquisition <- NULL
aor_survey_s<- aor_survey_s%>%
  pivot_longer(cols=c(-object_type), names_to="period")%>%pivot_wider(names_from=object_type)
aor_survey_s$period <- factor(aor_survey_s$period, levels=aor_survey_s$period)
par(mfrow=c(3,1))
par(mar=c(4,5,4,2))
## finds
bar_survey_s_fi <- barplot(aor_survey_s$vondst, 
                            names.arg = aor_survey_s$period,
                            ylab="aoristic weight",
                            ylim=c(0,max(aor_survey_s$vondst)+(0.2*max(aor_survey_s$vondst))),
                            main="Finds - Survey (systematic)")
text(bar_survey_s_fi,
     aor_survey_s$vondst+(0.1*max(aor_survey_s$vondst)),
     round(aor_survey_s$vondst,1))
## features
bar_survey_s_ft <- barplot(aor_survey_s$grondspoor, 
                            names.arg = aor_survey_s$period,
                            ylab="aoristic weight",
                            ylim=c(0,max(aor_survey_s$grondspoor)+(0.2*max(aor_survey_s$grondspoor))),
                            main="Features - Survey (systematic)")
text(bar_survey_s_ft,
     aor_survey_s$grondspoor+(0.1*max(aor_survey_s$grondspoor)),
     round(aor_survey_s$grondspoor,1))
## complexes
bar_survey_s_cx <- barplot(aor_survey_s$complex, 
                            names.arg = aor_survey_s$period,
                            ylab="aoristic weight",
                            ylim=c(0,max(aor_survey_s$complex)+(0.2*max(aor_survey_s$complex))),
                            main="Complexes - Survey (systematic)")
text(bar_survey_s_cx,
     aor_survey_s$complex+(0.1*max(aor_survey_s$complex)),
     round(aor_survey_s$complex,1))

##### 3 Coring####
aor_coring <- aor_archis%>% filter(acquisition =="Coring")
aor_coring$acquisition <- NULL
aor_coring<- aor_coring%>%
  pivot_longer(cols=c(-object_type), names_to="period")%>%pivot_wider(names_from=object_type)
aor_coring$period <- factor(aor_coring$period, levels=aor_coring$period)
par(mfrow=c(3,1))
par(mar=c(4,5,4,2))
## finds
bar_coring_fi <- barplot(aor_coring$vondst, 
                           names.arg = aor_coring$period,
                           ylab="aoristic weight",
                           ylim=c(0,max(aor_coring$vondst)+(0.2*max(aor_coring$vondst))),
                           main="Finds - Coring")
text(bar_coring_fi,
     aor_coring$vondst+(0.1*max(aor_coring$vondst)),
     round(aor_coring$vondst,1))
## features
bar_coring_ft <- barplot(aor_coring$grondspoor, 
                           names.arg = aor_coring$period,
                           ylab="aoristic weight",
                           ylim=c(0,max(aor_coring$grondspoor)+(0.2*max(aor_coring$grondspoor))),
                           main="Features - Coring")
text(bar_coring_ft,
     aor_coring$grondspoor+(0.1*max(aor_coring$grondspoor)),
     round(aor_coring$grondspoor,1))
## complexes
bar_coring_cx <- barplot(aor_coring$complex, 
                           names.arg = aor_coring$period,
                           ylab="aoristic weight",
                           ylim=c(0,max(aor_coring$complex)+(0.2*max(aor_coring$complex))),
                           main="Complexes - Coring")
text(bar_coring_cx,
     aor_coring$complex+(0.1*max(aor_coring$complex)),
     round(aor_coring$complex,1))

##### 4 Prospection####
aor_prospection <- aor_archis%>% filter(acquisition =="Prospection")
aor_prospection$acquisition <- NULL
aor_prospection<- aor_prospection%>%
  pivot_longer(cols=c(-object_type), names_to="period")%>%pivot_wider(names_from=object_type)
aor_prospection$period <- factor(aor_prospection$period, levels=aor_prospection$period)
par(mfrow=c(3,1))
par(mar=c(4,5,4,2))
## finds
bar_prospection_fi <- barplot(aor_prospection$vondst, 
                         names.arg = aor_prospection$period,
                         ylab="aoristic weight",
                         ylim=c(0,max(aor_prospection$vondst)+(0.2*max(aor_prospection$vondst))),
                         main="Finds - Prospection")
text(bar_prospection_fi,
     aor_prospection$vondst+(0.1*max(aor_prospection$vondst)),
     round(aor_prospection$vondst,1))
## features
bar_prospection_ft <- barplot(aor_prospection$grondspoor, 
                         names.arg = aor_prospection$period,
                         ylab="aoristic weight",
                         ylim=c(0,max(aor_prospection$grondspoor)+(0.2*max(aor_prospection$grondspoor))),
                         main="Features - Prospection")
text(bar_prospection_ft,
     aor_prospection$grondspoor+(0.1*max(aor_prospection$grondspoor)),
     round(aor_prospection$grondspoor,1))
## complexes
bar_prospection_cx <- barplot(aor_prospection$complex, 
                         names.arg = aor_prospection$period,
                         ylab="aoristic weight",
                         ylim=c(0,max(aor_prospection$complex)+(0.2*max(aor_prospection$complex))),
                         main="Complexes - Prospection")
text(bar_prospection_cx,
     aor_prospection$complex+(0.1*max(aor_prospection$complex)),
     round(aor_prospection$complex,1))

##### 5 Excavation####
aor_excavation <- aor_archis%>% filter(acquisition =="Excavation")
aor_excavation$acquisition <- NULL
aor_excavation<- aor_excavation%>%
  pivot_longer(cols=c(-object_type), names_to="period")%>%pivot_wider(names_from=object_type)
aor_excavation$period <- factor(aor_excavation$period, levels=aor_excavation$period)
par(mfrow=c(3,1))
par(mar=c(4,5,4,2))
## finds
bar_excavation_fi <- barplot(aor_excavation$vondst, 
                              names.arg = aor_excavation$period,
                              ylab="aoristic weight",
                              ylim=c(0,max(aor_excavation$vondst)+(0.2*max(aor_excavation$vondst))),
                              main="Finds - Excavation")
text(bar_excavation_fi,
     aor_excavation$vondst+(0.1*max(aor_excavation$vondst)),
     round(aor_excavation$vondst,1))
## features
bar_excavation_ft <- barplot(aor_excavation$grondspoor, 
                              names.arg = aor_excavation$period,
                              ylab="aoristic weight",
                              ylim=c(0,max(aor_excavation$grondspoor)+(0.2*max(aor_excavation$grondspoor))),
                              main="Features - Excavation")
text(bar_excavation_ft,
     aor_excavation$grondspoor+(0.1*max(aor_excavation$grondspoor)),
     round(aor_excavation$grondspoor,1))
## complexes
bar_excavation_cx <- barplot(aor_excavation$complex, 
                              names.arg = aor_excavation$period,
                              ylab="aoristic weight",
                              ylim=c(0,max(aor_excavation$complex)+(0.2*max(aor_excavation$complex))),
                              main="Complexes - Excavation")
text(bar_excavation_cx,
     aor_excavation$complex+(0.1*max(aor_excavation$complex)),
     round(aor_excavation$complex,1))
#####
# aantal per materiaalcategorie?
# archis_complex <- unique(archis_complex)
# 
# archis_feature$aantal[archis_feature$aantal==999] <- 9999
# 
# archis_find$aantal[archis_find$aantal==99999] <- 9999
# archis_find$aantal[archis_find$aantal==999] <- 9999
# archis_find$aantal[archis_find$aantal==29999] <- 9999
# 
# archis_feature <- unique(archis_feature)
# archis_find <- unique(archis_find)
# 
# ggplot(archis, aes(y = eindperi_1)) +
#   geom_bar()
# archis_find%>%arrange(periode_Nstart)%>%
# ggplot( aes(y = periode_Nstart)) +
#   geom_bar()
# 
# countplot(y=archis$eindperi_1)
# 
# 
# 
# 
# data_east2 <- data_east%>%
#   group_by(ts_n, ts, calBP_s, calBP_e, cat_2)%>%
#   summarise(m2=sum(m2), km2=sum(km2), `area%`=sum(`area%`))
