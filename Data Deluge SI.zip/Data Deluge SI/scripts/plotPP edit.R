
getFromNamespace(".PlotRateEstimateOnCurrentPlot","carbondate")

.PlotRateEstimateOnCurrentPlot_custom <- function (plot_cal_age_scale, posterior_rate, output_colour, 
          show_confidence_intervals, linewidth=line_w) 
{
  cal_age <- .ConvertCalendarAge(plot_cal_age_scale, posterior_rate$calendar_age_BP)
  graphics::lines(cal_age, posterior_rate$rate_mean, col = output_colour, lwd=linewidth)
  if (show_confidence_intervals) {
    graphics::lines(cal_age, posterior_rate$rate_ci_lower, 
                    col = output_colour, lty = 2, lwd=linewidth)
    graphics::lines(cal_age, posterior_rate$rate_ci_upper, 
                    col = output_colour, lty = 2,lwd=linewidth)
  }
}

environment(.PlotRateEstimateOnCurrentPlot_custom) <- asNamespace('carbondate')
assignInNamespace(".PlotRateEstimateOnCurrentPlot", 
                  .PlotRateEstimateOnCurrentPlot_custom, ns = "carbondate")


plotPP <- function (output_data, n_posterior_samples = 5000, calibration_curve = NULL, 
          plot_14C_age = TRUE, plot_cal_age_scale = "BP", show_individual_means = TRUE, 
          show_confidence_intervals = TRUE, interval_width = "2sigma", 
          bespoke_probability = NA, denscale = 3, resolution = 1, 
          n_burn = NA, n_end = NA, plot_pretty = TRUE, llim=10000, ulim=0, legend=TRUE) 
{
  arg_check <- .InitializeErrorList()
  .CheckOutputData(arg_check, output_data, "RJPP")
  .CheckInteger(arg_check, n_posterior_samples, lower = 10)
  .CheckCalibrationCurveFromOutput(arg_check, output_data, 
                                   calibration_curve)
  .CheckFlag(arg_check, plot_14C_age)
  .CheckChoice(arg_check, plot_cal_age_scale, c("BP", "AD", 
                                                "BC"))
  .CheckFlag(arg_check, show_individual_means)
  .CheckFlag(arg_check, show_confidence_intervals)
  .CheckIntervalWidth(arg_check, interval_width, bespoke_probability)
  .CheckNumber(arg_check, denscale, lower = 0)
  .CheckNumber(arg_check, resolution, lower = 0.01)
  .ReportErrors(arg_check)
  oldpar <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(oldpar))
  if (plot_pretty) {
    graphics::par(mgp = c(3, 0.7, 0), xaxs = "i", yaxs = "i", 
                  mar = c(5, 4.5, 4, 2) + 0.1, las = 1)
  }
  if (is.null(calibration_curve)) {
    calibration_curve <- get(output_data$input_data$calibration_curve_name)
  }
  rc_determinations <- output_data$input_data$rc_determinations
  rc_sigmas <- output_data$input_data$rc_sigmas
  F14C_inputs <- output_data$input_data$F14C_inputs
  if (plot_14C_age == TRUE) {
    calibration_curve <- .AddC14ageColumns(calibration_curve)
    if (F14C_inputs == TRUE) {
      converted <- .ConvertF14cTo14Cage(rc_determinations, 
                                        rc_sigmas)
      rc_determinations <- converted$c14_age
    }
  }
  else {
    calibration_curve <- .AddF14cColumns(calibration_curve)
    if (F14C_inputs == FALSE) {
      converted <- .Convert14CageToF14c(rc_determinations, 
                                        rc_sigmas)
      rc_determinations <- converted$f14c
    }
  }
  calibration_curve_colour <- "blue"
  calibration_curve_bg <- grDevices::rgb(0, 0, 1, 0.3)
  output_colour <- "purple"
  start_age <- ceiling(min(output_data$rate_s[[1]])/resolution) * 
    resolution
  end_age <- floor(max(output_data$rate_s[[1]])/resolution) * 
    resolution
  if (end_age == max(output_data$rate_s[[1]])) {
    end_age <- end_age - resolution
  }
  calendar_age_sequence <- seq(from = start_age, to = end_age, 
                               by = resolution)
  xlim <- c(llim, ulim)
  posterior_rate <- FindPosteriorMeanRate(output_data, calendar_age_sequence, 
                                          n_posterior_samples, interval_width, bespoke_probability, 
                                          n_burn, n_end)
  if (show_individual_means) {
    n_iter <- output_data$input_parameters$n_iter
    n_thin <- output_data$input_parameters$n_thin
    n_burn <- .SetNBurn(n_burn, n_iter, n_thin)
    n_end <- .SetNEnd(n_end, n_iter, n_thin)
    calendar_age_means <- apply(output_data$calendar_ages[(n_burn + 
                                                             1):n_end, ], 2, mean)
  }
  ylim_rate <- c(0, denscale * max(posterior_rate$rate_mean))
  .PlotCalibrationCurveAndInputData(plot_cal_age_scale, xlim, 
                                    calibration_curve, rc_determinations, plot_14C_age, 
                                    calibration_curve_colour, calibration_curve_bg, interval_width, 
                                    bespoke_probability, title =  title_custom)
  .SetUpDensityPlot(plot_cal_age_scale, xlim, ylim_rate)
  if (show_individual_means) {
    calendar_age_means <- .ConvertCalendarAge(plot_cal_age_scale, 
                                              calendar_age_means)
    graphics::rug(calendar_age_means, side = 1, quiet = TRUE)
  }
  .PlotRateEstimateOnCurrentPlot_custom(plot_cal_age_scale, posterior_rate, 
                                 output_colour, show_confidence_intervals)
  if(legend==TRUE){
  .AddLegendToRatePlot(output_data, show_confidence_intervals, 
                       interval_width, bespoke_probability, calibration_curve_colour, 
                       output_colour)
    }
  invisible(posterior_rate)
  axis(1, at = seq(ulim,llim, by=100),labels=FALSE, tck=-0.01)
  axis(1, at = seq(ulim,llim, by=500),labels=FALSE, tck=-0.02)
  axis(1, at = seq(ulim,llim, by=1000),labels=FALSE, tck=-0.03)
  source("scripts/phaserect.R")
}

environment(plotPP) <- asNamespace('carbondate')
assignInNamespace("PlotPosteriorMeanRate", plotPP, ns = "carbondate")


# plot posterior change points ####
plotPPCP <- function (output_data, n_changes = c(1, 2, 3), plot_cal_age_scale = "BP", 
                      n_burn = NA, n_end = NA, kernel_bandwidth = NA, ActivateLegend, llim, ulim) 
{
  n_iter <- output_data$input_parameters$n_iter
  n_thin <- output_data$input_parameters$n_thin
  arg_check <- .InitializeErrorList()
  .CheckOutputData(arg_check, output_data, "RJPP")
  .CheckIntegerVector(arg_check, n_changes, lower = 1, upper = 6, 
                      max_length = 4)
  .CheckChoice(arg_check, plot_cal_age_scale, c("BP", "AD", 
                                                "BC"))
  .CheckNBurnAndNEnd(arg_check, n_burn, n_end, n_iter, n_thin)
  if (!is.na(kernel_bandwidth)) 
    .CheckNumber(arg_check, kernel_bandwidth, lower = 0)
  .ReportErrors(arg_check)
  n_burn <- .SetNBurn(n_burn, n_iter, n_thin)
  n_end <- .SetNEnd(n_end, n_iter, n_thin)
  max_density <- 0
  all_densities <- list()
  posterior_n_internal_changes <- output_data$n_internal_changes[n_burn + 
                                                                   1:n_end]
  posterior_rate_s <- output_data$rate_s[n_burn + 1:n_end]
  cal_age_range <- sort(output_data$input_parameters$pp_cal_age_range)
  if (is.na(kernel_bandwidth)) 
    kernel_bandwidth <- diff(cal_age_range)/50
  colors <- c("blue", "darkgreen", "red", "purple", "cyan3", 
              "darkgrey")
  legend <- NULL
  for (n_change in n_changes) {
    legend <- c(legend, paste(n_change, "internal changes"))
    index <- which(posterior_n_internal_changes == n_change)
    if (length(index) == 0) {
      warning(paste("No posterior samples with", n_change, 
                    "internal changes"))
      next
    }
    extracted_posteriors <- do.call(rbind, posterior_rate_s[index])
    for (j in 2:(n_change + 1)) {
      tryCatch({
        smoothed_density <- stats::density(extracted_posteriors[, 
                                                                j], bw = kernel_bandwidth, from = cal_age_range[1], 
                                           to = cal_age_range[2])
        if (max(smoothed_density$y) > max_density) 
          max_density <- max(smoothed_density$y)
        this_line <- list(x = smoothed_density$x, y = smoothed_density$y, 
                          n_change = n_change, j = j)
        all_densities <- append(all_densities, list(this_line))
      }, error = function(cond) {
        message(paste("Could not calculate density for n_change =", 
                      n_change, ", j =", j, ": ", conditionMessage(cond)))
      })
    }
  }
  cal_age_range <- .ConvertCalendarAge(plot_cal_age_scale, 
                                       cal_age_range)
  if (plot_cal_age_scale == "AD") {
    x_label <- "Calendar Age (cal AD)"
  }
  else if (plot_cal_age_scale == "BC") {
    x_label <- "Calendar Age (cal BC)"
  }
  else {
    x_label <- "Calendar Age (cal yr BP)"
  }
  graphics::plot(x = NA, y = NA, xlim = c(llim, ulim), 
                 ylim = c(0, max_density * 1.2), xlab = x_label, ylab = "Density", 
                 type = "n",yaxs="i", xaxs="i")
  axis(1, at = seq(ulim,llim, by=100),labels=FALSE, tck=-0.01)
  axis(1, at = seq(ulim,llim, by=500),labels=FALSE, tck=-0.02)
  axis(1, at = seq(ulim,llim, by=1000),labels=FALSE, tck=-0.03)
  source("scripts/phaserect.R")
  for (line in all_densities) {
    cal_age_line_x <- .ConvertCalendarAge(plot_cal_age_scale, 
                                          line$x)
    graphics::lines(cal_age_line_x, line$y, lty = line$n_change, 
                    col = colors[line$n_change], lwd = 2)
  }
  if (ActivateLegend==1){
  graphics::legend("topright", legend = legend, lty = n_changes, 
                   col = colors[n_changes])
  }
  return(all_densities)
}


environment(plotPPCP) <- asNamespace('carbondate')
assignInNamespace("PlotPosteriorChangePoints", plotPPCP, ns = "carbondate")
