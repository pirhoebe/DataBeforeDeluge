#climate phases according to Rasmussen et al. 2014)
# rect(x=       c(16000, 14025, 13610, 13261, 12846, 11470, 10375, 9300, 8250),
#      xright = c(14642, 13904, 13550, 13049, 11653, 11350, 10225, 9190, 8090),
#      ybottom = 0,
#      ytop = 10,
#      col= rgb(0,0,0,alpha=0.2),
#      border=NA)


# start 16000, 14025, 13610, 13261, 12846, 11470, 9300, 8250
# end 14642, 13904, 13550, 13049, 11653, 11350, 9190, 8090

# prepare cold climate phases as following Rasmussen et al. 2014 + 10.3ka (Bond et al 2001)
start <- c(lowerlim, 14025, 13610, 13261, 12807, 11470, 10375,  9300, 8250)
end <- c(14642, 13904, 13550, 13049, 11653, 11350, 10225,  9190, 8090)
centre <- start-((start-end)/2)
name <- c("GS-2", "GI\n1d", "GI\n1c2","GI\n1b","GS-1", "11.4ka\nevent", "10,3ka\nevent", 
          "9.3ka\nevent", "8.2ka\nevent")
event <- data.frame(name, start, end, centre)



par(xpd=NA)
#placement options ####

#phase rectangles throughout graph
rect(x= event$start,
     xright = event$end,
     ybottom = par("usr")[3],
     ytop = par("usr")[4],
     col= rgb(0,0,0,alpha=0.2),
     border=NA)

#phase rectangles as part of plot area
# rect(x= event$start,
#      xright = event$end,
#           ybottom = par("usr")[4]-(0.15*(par("usr")[4])),
#           ytop = par("usr")[4]-(0.85*(par("usr")[4])),
#      col= rgb(0,0,0,alpha=0.2),
#      border=NA)

#phase rectangles below plot area
# rect(x= event$start,
#      xright = event$end,
#      ybottom =  par("usr")[3]-(0.07*(par("usr")[4])),
#      ytop = par("usr")[3]-(0.02*(par("usr")[4])),
#      col= rgb(0,0,1,alpha=0.5),
#      border=NA)

#phase rectangles above top of graph
# rect(x= event$start,
#      xright = event$end,
#      ybottom = par("usr")[4]+(0.05*(par("usr")[4])),
#      ytop = par("usr")[4]+(0.10*(par("usr")[4])),
#      col= rgb(0,0,1,alpha=0.5),
#      border=NA)


#phase rectangles at top of graph
# rect(x= event$start,
#      xright = event$end,
#      ybottom = par("usr")[4]-(0.05*(par("usr")[4])),
#      ytop = par("usr")[4],
#      col= rgb(0,0,0,alpha=0.5),
#      border=NA)

#phase rectangles at bottom of graph
# rect(x= event$start,
#      xright = event$end,
#      ybottom = 0,
#      ytop = par("usr")[3]+(0.05*(par("usr")[4])),
#      col= rgb(0,0,0,alpha=0.3),
#      border=NA)

#active placement option ####

if(exists("phaselabels")==FALSE ){
phaselabels <- FALSE
message("note: phase labels are not turned on")
}
if(phaselabels =="TRUE"){
text(x=event$centre, 
     y=par("usr")[4]-(0.4 # plot text at percentage of plot area
                      *(par("usr")[4])), 
     labels=event$name, col="black")
}

par(xpd=FALSE)