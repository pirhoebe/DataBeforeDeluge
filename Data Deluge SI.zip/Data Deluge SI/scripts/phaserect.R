#climate phases according to Rasmussen et al. 2014)
# rect(x=       c(16000, 14025, 13610, 13261, 12846, 11470, 10375, 9300, 8250),
#      xright = c(14642, 13904, 13550, 13049, 11653, 11350, 10225, 9190, 8090),
#      ybottom = 0,
#      ytop = 10,
#      col= rgb(0,0,0,alpha=0.2),
#      border=NA)


# start 16000, 14025, 13610, 13261, 12846, 11470, 9300, 8250
# end 14642, 13904, 13550, 13049, 11653, 11350, 9190, 8090

# prepare cold climate phases as following Rasmussen et al. 2014 + 10.3ka (Bond et al 2001)
start <- c(16000, 14025, 13610, 13261, 12807, 11470, 10375,  9300, 8250)
end <- c(14642, 13904, 13550, 13049, 11653, 11350, 10225,  9190, 8090)
centre <- start-((start-end)/2)
name <- c("GS-2", "GI\n1d", "GI\n1c2","GI\n1b","GS-1", "11.4", "10,3", 
          "9.3", "8.2")
event <- data.frame(name, start, end, centre)

if(exists("rowcalBC")==TRUE ){
if(rowcalBC=="BP"){
event$start=event$start*-1
event$end=event$end*-1
event$centre=event$centre*-1
  message("note: dates in calBP")}
  else{
  event$start=event$start-1950
  event$start=event$start*-1
  event$end=event$end-1950
  event$end=event$end*-1
  event$centre=event$centre-1950
  event$centre=event$centre*-1
  message("note: dates converted to comply with rowcal BC scale")}}

par(xpd=NA)
#placement options ####
if(exists("phasepl")==FALSE ){
  phasepl <- 1
  message("note: phase rectangles throughout graph")
  rect(x= event$start,
       xright = event$end,
       ybottom = par("usr")[3],
       ytop = par("usr")[4],
       col= rgb(0,0,0,alpha=0.2),
       border=NA)
}
if(exists("phasepl")==TRUE){
if(phasepl==1){  
message("1: phase rectangles throughout graph")
#phase rectangles throughout graph
rect(x= event$start,
     xright = event$end,
     ybottom = par("usr")[3],
     ytop = par("usr")[4],
     col= rgb(0,0,0,alpha=0.2),
     border=NA)}

#phase rectangles as part of plot area
# rect(x= event$start,
#      xright = event$end,
#           ybottom = par("usr")[4]-(0.15*(par("usr")[4])),
#           ytop = par("usr")[4]-(0.85*(par("usr")[4])),
#      col= rgb(0,0,0,alpha=0.2),
#      border=NA)

#phase rectangles below plot area
# rect(x= event$start,
#      xright = event$end,
#      ybottom =  par("usr")[3]-(0.07*(par("usr")[4])),
#      ytop = par("usr")[3]-(0.02*(par("usr")[4])),
#      col= rgb(0,0,1,alpha=0.5),
#      border=NA)
if(phasepl==2){  
message("2: phase rectangles above top of graph")
# par(xpd=NA)
rect(x= event$start,
     xright = event$end,
     ybottom = par("usr")[4]+(0.0*(par("usr")[4])),
     ytop = par("usr")[4]+(0.10*(par("usr")[4]-par("usr")[3])),
     col= rgb(0,0,0,alpha=0.5),
     border=NA)
}
# par(xpd=FALSE)
  }


#phase rectangles at top of graph
# rect(x= event$start,
#      xright = event$end,
#      ybottom = par("usr")[4]-(0.05*(par("usr")[4])),
#      ytop = par("usr")[4],
#      col= rgb(0,0,0,alpha=0.5),
#      border=NA)

#phase rectangles at bottom of graph
# rect(x= event$start,
#      xright = event$end,
#      ybottom = 0,
#      ytop = par("usr")[3]+(0.05*(par("usr")[4])),
#      col= rgb(0,0,0,alpha=0.3),
#      border=NA)

#active placement option ####

if(exists("phaselabels")==FALSE ){
phaselabels <- FALSE
message("note: phase labels are not turned on")
}
if(exists("ppos")==FALSE ){
  ppos <- 0.5
  message("note: ppos=0.5")
}
if(phaselabels ==TRUE){
  
text(x=event$centre, 
     y=par("usr")[4]-(ppos # plot text at percentage of plot area
                      *(par("usr")[4]-par("usr")[3])), 
     labels=event$name, col="black")
}

par(xpd=FALSE)