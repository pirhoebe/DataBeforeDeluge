YD_EH <- read_excel("data/timing GS-1 EH.xlsx", sheet=1)
YD_EH_rect <- read_excel("data/timing GS-1 EH.xlsx", sheet=2)

INTCAL20 <- read.csv('https://www.intcal.org/curves/intcal20.14c',
                     encoding="UTF-8",skip=11,header=F)
colnames(INTCAL20) <- c("BP","CRA","Error","D14C","Sigma")

### load NGRIP data ###
NGRIP<- pg_data(doi='10.1594/PANGAEA.824889')
NGRIPdata <- NGRIP[[1]]$data 
colnames(NGRIPdata) <- c("depth", "age", "d18O")

NGRIPdata$calBP <-NGRIPdata$age*1000 
NGRIPdata$calBP <- round(NGRIPdata$calBP, 0)
NGRIPdata <- NGRIPdata %>% filter(calBP>=6000 & calBP<=16000)
NGRIPdata$age <- NULL
# create aoristic chronozone dataframe. 
chronozones <- data.frame(row.names=1:5)
chronozones$name <- c("YD", "Preboreal", "Boreal", "Early Atlantic", " Middle Atlantic")
chronozones$llim <- c(12807, 11653, 10800, 9190, 8090)
chronozones$ulim <- c(11653, 10800, 9190, 8090, 6000)
chronozones$col <- c( "plum", "palegreen3", "palegreen4", 
                      "chartreuse4", "green4")


lowerlim=16000
upperlim=10000

# YD_EH$topplot=-36.2
# YD_EH$botplot=-36.0
# # YD_EH$source <- factor(YD_EH$source,
# #                        levels=c("NGRIP",
# #                        "LETR",
# #                        "MFM",
# #                        "expmod" 
# #                        "climod"     "PP fauna",
# #                        )
# # ?factor
# for( i in 1:length(unique(YD_EH$source))){
#   cat=unique(YD_EH$source)[i]
# 
#   YD_EH$topplot[YD_EH$source==cat] <- YD_EH$topplot[YD_EH$source==cat]+i*0.4
#   YD_EH$botplot[YD_EH$source==cat] <- YD_EH$botplot[YD_EH$source==cat]+i*0.4
# }

par(mar=c(3,5,2,5))
plot(NGRIPdata$calBP, NGRIPdata$d18O,
     xlim=c(13000,11000),ylim=c(-43,-33),
     axes=FALSE,
     xlab="",
     ylab="",
     type="l", col="firebrick", lwd=2)
box()
rect(x= c(12807,11470),
     xright = c(11653,11350),
     ybottom = par("usr")[3],
     ytop = par("usr")[4],
     col= rgb(0,0,0,alpha=0.2),
     border=NA)
mtext(at=-38, expression('NGRIP '*delta^{18}*'O'), side=2, line=2, col="black", las=3, cex=0.8)
mtext(at=-38, "Rasmussen 2014", side=2, line=3, col="black", las=3, cex=0.9)
mtext("Calibrated age BP", side=1, line=2, col="black", las=1, cex=0.9)

axis(2, at= c(-40,-35), col="black", col.axis="black", las=1)
axis(2, at = seq(-43, -33,by=1),labels=FALSE, tck=-0.01)
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.02)
axis(1, at = seq(upperlim,lowerlim, by=1000),labels=TRUE, tck=-0.03)
rect(x= YD_EH_rect$start,
     xright = YD_EH_rect$end,
     ybottom = YD_EH_rect$bottom,
     ytop = YD_EH_rect$top,
     col= c(rgb(0,0,0,0.3),
            rgb(0,0,0,0.3),
            rgb(1,0,0,0.3),
            rgb(1,0,0,0.3), 
            rgb(0,0,1,0.3),
            rgb(1,0,0,0.3), 
            rgb(1,0,0,0.3),
            rgb(0,0,1,0.3),
            rgb(0,0.4,0.6,0.3),
            rgb(0,0.4,0.2,0.3),
            rgb(0,0.4,0.2,0.3)
            ),
     border=NA)


points(x=YD_EH$date, y=(YD_EH$bottom+YD_EH$top)/2, 
       col=c("firebrick","cyan4","darkgreen"), type="p", pch=19, cex=1)
segments(x0=YD_EH$date+YD_EH$error, 
         x1=YD_EH$date-YD_EH$error,
        y0=(YD_EH$top+YD_EH$bottom)/2, 
         y1=(YD_EH$top+YD_EH$bottom)/2,
          col=c("firebrick","cyan4","darkgreen"),
         lwd=3)
segments(x0=YD_EH$date-YD_EH$error, 
         x1=YD_EH$date-YD_EH$error,
         y0=YD_EH$bottom+0.1, 
         y1=YD_EH$top-0.1,
         col=c("firebrick","cyan4","darkgreen"),
         lwd=3)
segments(x0=YD_EH$date+YD_EH$error, 
         x1=YD_EH$date+YD_EH$error,
         y0=YD_EH$bottom+0.1, 
         y1=YD_EH$top-0.1,
         col=c("firebrick","cyan4","darkgreen"),
         lwd=3)
legend("bottomright", y=-33.1,unique(YD_EH$source), col=c("firebrick","cyan4","darkgreen"), pch=19)
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.02)
axis(1, at = seq(upperlim,lowerlim, by=1000),labels=FALSE, tck=-0.03)

axis(3, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(3, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.02)
axis(3, at = seq(upperlim,lowerlim, by=1000),labels=FALSE, tck=-0.03)
mtext("B.4 forest", at=-34.5, side=4, padj=0,line=0.2, col="black", las=2)
mtext("B.4 tundra", at=-35, side=4, padj=0,line=0.2, col="black", las=2)
mtext("CII.5a clim", at=-36, side=4, padj=0,line=0.2, col="black", las=2)
mtext("CII.5b exp", at=-36.5, side=4, padj=0,line=0.2, col="black", las=2)
mtext("Younger Dryas\nGS-1", at=12249.5, side=1,line=-1, col="black", las=1)
mtext("11.4ka\nevent", at=11410, side=1,line=-1, col="black", las=1)


