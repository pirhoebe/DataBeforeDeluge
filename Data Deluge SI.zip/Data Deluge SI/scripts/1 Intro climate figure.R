source("scipts/read libraries.R")
Vinther<- read_excel("data/Vinther2009 Greenland d18O.xlsx")
### load NGRIP data ###
NGRIP<- pg_data(doi='10.1594/PANGAEA.824889')
NGRIPdata <- NGRIP[[1]]$data 
colnames(NGRIPdata) <- c("depth", "age", "d18O")

NGRIPdata$calBP <-NGRIPdata$age*1000 
NGRIPdata$calBP <- round(NGRIPdata$calBP, 0)
NGRIPdata <- NGRIPdata %>% filter(calBP>=6000 & calBP<=16000)
NGRIPdata$age <- NULL
 
chronozones <- data.frame(row.names=1:8)
chronozones$name <- c("Older Dryas", "Bølling", "Allerød", "Younger Dryas", 
                      "Preboreal", "Early Boreal", "Late Boreal", "Atlantic")
chronozones$llim <- c(16000, 14650, 13904, 12846, 11653, 10800, 9190, 8090)
chronozones$ulim <- c(14650, 13904, 12846, 11653, 10800, 9190, 8090, 6000)
chronozones$col <- c( "white","plum2", "palegreen2","plum2", "palegreen2", "palegreen3", 
                      "palegreen4", "chartreuse4")

chronozones2 <- data.frame(row.names=1:8)
chronozones2$name <- c("Older Dryas", "Bølling", "Allerød", "Younger Dryas", "Preboreal", "Boreal", "Early Atlantic", " Middle Atlantic")
chronozones2$llim <- c(16000, 14650, 13904, 12809, 11653, 10800, 9190, 8090)
chronozones2$ulim <- c(14650, 13904, 12809, 11653, 10800, 9190, 8090, 6000)
chronozones2$col <- c( "white","plum", "palegreen2","plum", "palegreen2", "palegreen3", 
                      "chartreuse4", "green4")


ESL_models <- read_excel("data/ESL models.xlsx")


f_britain <- read.delim("data/forest britain.txt", sep=',')
f_atlantic <- read.delim("data/forest atlantic.txt", sep=',')
f_central <- read.delim("data/forest central.txt", sep=',')
f_britain$date <- f_britain$date*-1000
f_atlantic$date <- f_atlantic$date*-1000
f_central$date <- f_central$date*-1000
#######################################################################

par(mfrow=c(1,1))
par(oma=c(2  ,1,1,1))
par(mar=c(1.5,4,3,4))
# _NGRIP ####
lowerlim=16000
upperlim=6000
     
     
plot(x=NGRIPdata$calBP,
     y=NGRIPdata$d18O,
     ylim=c(-48,-30),
     xlim=c(lowerlim,upperlim),
     axes = FALSE,
     yaxt="n",
     type="l",
     xlab=" ",
     ylab=" ",
     col="firebrick",lwd=2)

mtext("Calibrated age BP", side=1, line=2, col="black", las=1, cex=0.8)

axis(2, at= c(-45,-40,-35), col="black", tck=-0.03,col.axis="firebrick")
axis(2, at = seq(-44, -35,by=1),labels=FALSE, tck=-0.01)
mtext(at=-40, expression('NGRIP '*delta^{18}*'O'), side=2, line=2, col="firebrick", las=3, cex=0.8)
mtext(at=-40, "Rasmussen 2014", side=2, line=3, col="firebrick", las=3, cex=0.8)


axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.02)
axis(1, at = seq(upperlim,lowerlim, by=1000),labels=TRUE, tck=-0.03)
axis(3, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=0.01)
axis(3, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=0.02)
axis(3, at = seq(upperlim,lowerlim, by=1000),labels=FALSE, tck=0.03)
par(xpd=NA)
rect(x=chronozones$llim,
     xright = chronozones$ulim,
     ybottom = par("usr")[4]+(0.11*(par("usr")[4]-par("usr")[3])),
     ytop = par("usr")[4]+(0.20*(par("usr")[4]-par("usr")[3])),
     col=chronozones$col, # add chronozone colour to chronozones
     border="black")
text(x=chronozones$llim-((chronozones$llim-chronozones$ulim)/2), 
     y=par("usr")[4]+(0.15*(par("usr")[4]-par("usr")[3])), 
     labels=chronozones$name, col="black", cex=0.6)
rect(x=chronozones2$llim,
     xright = chronozones2$ulim,
     ybottom = par("usr")[4]+(0.01*(par("usr")[4]-par("usr")[3])),
     ytop = par("usr")[4]+(0.10*(par("usr")[4]-par("usr")[3])),
     col=chronozones2$col, # add chronozone colour to chronozones2
     border="black")
text(x=chronozones2$llim-((chronozones2$llim-chronozones2$ulim)/2), 
     y=par("usr")[4]+(0.05*(par("usr")[4]-par("usr")[3])), 
     labels=chronozones2$name, col="black", cex=0.6)

text(x=16000, 
     y=par("usr")[4]+(0.18*(par("usr")[4]-par("usr")[3])), 
     labels="Chron 1  ", col="black", cex=0.8, adj=1)
text(x=16000, 
     y=par("usr")[4]+(0.06*(par("usr")[4]-par("usr")[3])), 
     labels="Chron 2  ", col="black", cex=0.8, adj=1)

phaserect=1
phaselabels=TRUE
ppos=0.95
source("scripts/phaserect2.R")

par(new=TRUE)
plot(x=f_atlantic$date,
     y=f_atlantic$forest_cover,
     type="l",
     col="cyan4",
     lwd=2,
     xaxt='n',
     yaxs="i",
     axes=FALSE,
     xlab="", ylab="",
     xlim=c(16000,6000),
     ylim=c(-150,110))
lines(x=f_central$date,
      y=f_central$forest_cover,
      type="l",
      col="green4",
      lwd=2)
lines(x=f_britain$date,
      y=f_britain$forest_cover,
      type="l",
      col="orange3",
      lwd=2)
text(x=c(12000),
     y=f_atlantic$forest_cover[f_atlantic$date==f_atlantic$date[1]], 
     labels="Atlantic", col=c("cyan4"), cex=0.8, pos=2)
text(x=c(12000),
     y=f_central$forest_cover[f_central$date==f_central$date[1]], 
     labels="Central", col=c("green4"), cex=0.8, pos=2)
text(x=c(12000),
     y=f_britain$forest_cover[f_britain$date==f_britain$date[1]], 
     labels="Britain", col=c("orange3"), cex=0.8, pos=2)
axis(4, at= c(0,50,100), labels=TRUE, tck=-0.03,col="black", col.axis="darkgreen")
axis(4, at= seq(0,100,by=10), labels=FALSE, tck=-0.01,col="black", col.axis="darkgreen")
mtext(at=50,"Forest cover %\n Zanon et al. 2012", side=4, las=3, cex=0.8,line=3, col="darkgreen")





par(new=TRUE)
plot(x=ESL_models$calBP,
     y=ESL_models$`Lambeck ea 2015 NS`,
     xlim=c(16000,6000),
     ylim=c(-110,100),
     xlab="",
     ylab="",
     xaxt='n',
     yaxs="i",
     type="l",
     col="blue",
     axes=FALSE,
     lwd=2)
axis(4, at= c(-100,-75,-50,-25, 0), labels=TRUE, tck=-0.03,col="black", col.axis="darkblue")
axis(4, at= seq(-100,0,by=10), labels=FALSE, tck=-0.01,col="black", col.axis="darkblue")
mtext(at=-50,"Eustatic Sea Level\nLambeck 2015", side=4, las=3, cex=0.8,line=3, col="darkblue")
