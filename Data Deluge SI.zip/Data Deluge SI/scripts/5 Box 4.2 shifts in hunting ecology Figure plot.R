layout.matrix <- matrix(c(1,2,3,4), nrow=4, ncol=1)
layout(mat=layout.matrix, heights=c(2,1,2,1), widths=c(2))
layout.show(8)
lowerlim=16000
upperlim=10000
# par(mfrow=c(4,2))
par(oma=c(3,1,1,1))
par(mar=c(2,4.5,4,4.5))



## POISSON PROCESS ####
#______________________________________________________________________________
### tundra ####
#______________________________________________________________________________
plot(x=INTCAL20$BP[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim], 
     y=INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim],
     xlim=rev(range(INTCAL20$BP[INTCAL20$BP<=lowerlim &
                                  INTCAL20$BP>=upperlim])),
     ylim=c(min(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])-2000,
            max(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])+1000),
     type="l", col="royalblue", lwd=2,
     axes= FALSE, xaxs="i",xlab="", ylab="")
axis(4, at=c(10000,12000,14000,16000),labels=TRUE,tck=-0.05,col="black", col.axis="royalblue")
axis(4, at=seq(1000,16000,by=1000), labels=FALSE,tck=-0.03,col="black", col.axis="royalblue")
axis(4, at = tundra$c14age, labels = FALSE, tck=0.02)
mtext(expression(text=''^14*'C age BP'), side=4, line=3, col="royalblue", cex=0.7)
phaserect=1
rm(phaselabels)

par(new=TRUE)
plot(x=tundra.PP_fit$calendar_age_BP,
     y=tundra.PP_fit$rate_mean,
     col="cyan4",
     lwd=2,
     type="l", 
     xaxs="i",
     xlim=c(16000, 10000),
     ylim=c(0,max(tundra.PP_fit$rate_ci_upper+
                    (0.2*max(tundra.PP_fit$rate_ci_upper)))),
     # ylim=c(0,1.75),
     ylab=NA,
     xlab=NA)
# abline(h=0)
mtext("density estimate", side=2, line=3, col="cyan4", cex=0.7)
mtext("a. Tundra PP", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
polygon(x=c(tundra.PP_fit$calendar_age_BP,
            rev(tundra.PP_fit$calendar_age_BP)),
        y=c(tundra.PP_fit$rate_ci_upper,
            rev(tundra.PP_fit$rate_ci_lower)),
        col=rgb(0,0.5,1,0.3), 
        border=NA)
polygon(x=c(tundra.PP_fit$calendar_age_BP,
            rev(tundra.PP_fit$calendar_age_BP)),
        y=c(tundra.PP_fit$rate_ci_upper,
            rev(tundra.PP_fit$rate_ci_lower)),
        col=NA, 
        border="cyan4",
        lty=2)
lines(x=tundra.PP_fit$calendar_age_BP,
      y=tundra.PP_fit$rate_mean,
      col="cyan4",
      lwd=2)
for(i in 1:length(tundra.PPCP)){
  if(tundra.PPCP[[i]]$n_change==6){
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="cyan4")}
  if(tundra.PPCP[[i]]$n_change==5){
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="cyan4")}
}
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)
axis(1, at = tundra$calBPmean, labels = FALSE, tck=0.02)
box()
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015)

## POSTERIOR CHANGE POINTS ####
#______________________________________________________________________________

plot(x=c(lowerlim,upperlim), y=c(0,0.002), xlim=c(16000,10000),
     type="n", xaxs="i",yaxs="i",xlab="", ylab="")
source("scripts/phaserect.R")
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05*3)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03*3)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015*3)
mtext(paste("b. Change Points: 6 internal changes"), side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
mtext("Probability", side=2, line=3, col="black", cex=0.7)
for(i in 1:length(tundra.PPCP)){
  if(tundra.PPCP[[i]]$n_change==6){
    lines(x=tundra.PPCP[[i]]$x,
          y=tundra.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(1,0,0.6,0.5))
          col="cyan4")
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="cyan4")}
  if(tundra.PPCP[[i]]$n_change==5){
    lines(x=tundra.PPCP[[i]]$x,
          y=tundra.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(0.5, 0,0,0.5))
          col="cyan4")
    abline(v=tundra.PPCP[[i]]$x[tundra.PPCP[[i]]$y==max(tundra.PPCP[[i]]$y)],
           lty=2, lwd=2,col="cyan4")}
}
box()


## POISSON PROCESS ####
#______________________________________________________________________________
### forest ####
#______________________________________________________________________________
plot(x=INTCAL20$BP[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim], 
     y=INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim],
     xlim=rev(range(INTCAL20$BP[INTCAL20$BP<=lowerlim &
                                  INTCAL20$BP>=upperlim])),
     ylim=c(min(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])-2000,
            max(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])+1000),
     type="l", col="royalblue", lwd=2,
     axes= FALSE, xaxs="i",xlab="", ylab="")
axis(4, at=c(10000,12000,14000,16000),labels=TRUE,tck=-0.05,col="black", col.axis="royalblue")
axis(4, at=seq(1000,16000,by=1000), labels=FALSE,tck=-0.03,col="black", col.axis="royalblue")
axis(4, at = forest$c14age, labels = FALSE, tck=0.02)
mtext(expression(text=''^14*'C age BP'), side=4, line=3, col="royalblue", cex=0.7)
phaserect=1
rm(phaselabels)

par(new=TRUE)
plot(x=forest.PP_fit$calendar_age_BP,
     y=forest.PP_fit$rate_mean,
     col="darkgreen",
     lwd=2,
     type="l", 
     xaxs="i",
     xlim=c(16000, 10000),
     ylim=c(0,max(forest.PP_fit$rate_ci_upper+
                    (0.2*max(forest.PP_fit$rate_ci_upper)))),
     # ylim=c(0,1.75),
     ylab=NA,
     xlab=NA)
# abline(h=0)
mtext("density estimate", side=2, line=3, col="darkgreen", cex=0.7)
mtext("c. Forest PP", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
polygon(x=c(forest.PP_fit$calendar_age_BP,
            rev(forest.PP_fit$calendar_age_BP)),
        y=c(forest.PP_fit$rate_ci_upper,
            rev(forest.PP_fit$rate_ci_lower)),
        col=rgb(0,0.6,0.2,0.3), 
        border=NA)
polygon(x=c(forest.PP_fit$calendar_age_BP,
            rev(forest.PP_fit$calendar_age_BP)),
        y=c(forest.PP_fit$rate_ci_upper,
            rev(forest.PP_fit$rate_ci_lower)),
        col=NA, 
        border="darkgreen",
        lty=2)
lines(x=forest.PP_fit$calendar_age_BP,
      y=forest.PP_fit$rate_mean,
      col="darkgreen",
      lwd=2)
for(i in 1:length(forest.PPCP)){
  if(forest.PPCP[[i]]$n_change==6){
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="darkgreen")}
  if(forest.PPCP[[i]]$n_change==5){
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="darkgreen")}
}
par(xpd=NA)
source("scripts/phaserect.R")
par(xpd=FALSE)
axis(1, at = forest$calBPmean.x, labels = FALSE, tck=0.02)
box()
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015)

## POSTERIOR CHANGE POINTS ####
#______________________________________________________________________________

plot(x=c(lowerlim,upperlim), y=c(0,0.002), xlim=c(16000,10000),
     type="n", xaxs="i",yaxs="i",xlab="", ylab="")
source("scripts/phaserect.R")
axis(1, at = seq(10000,16000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(10000, 16000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(10000,16000, by=100), labels = FALSE, tck=-0.015)
mtext(paste("d. Change Points: 6 internal changes"), side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
mtext("Probability", side=2, line=3, col="black", cex=0.7)
for(i in 1:length(forest.PPCP)){
  if(forest.PPCP[[i]]$n_change==6){
    lines(x=forest.PPCP[[i]]$x,
          y=forest.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(1,0,0.6,0.5))
          col="darkgreen")
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="darkgreen")}
  if(forest.PPCP[[i]]$n_change==5){
    lines(x=forest.PPCP[[i]]$x,
          y=forest.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(0.5, 0,0,0.5))
          col="darkgreen")
    abline(v=forest.PPCP[[i]]$x[forest.PPCP[[i]]$y==max(forest.PPCP[[i]]$y)],
           lty=2, lwd=2,col="darkgreen")}
}
box()
beep(4)
