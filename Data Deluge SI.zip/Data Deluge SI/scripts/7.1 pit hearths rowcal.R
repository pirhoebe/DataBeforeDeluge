data_DE_pits <- read_excel("data/data_Gehlen20pits.xlsx")
data_BE_pits <- read_excel("data/data_BE pits.xlsx")
data_NL_pits <- read_excel("data/data FINAL (19-12-2024).xlsx")


data_DE_pits <- data_DE_pits %>% filter(feature == "pit hearth")
data_NL_pits <- data_NL_pits %>% filter(feature == "pit hearth")
data_DE_pits <- filter(data_DE_pits, !duplicated(data_DE_pits$labcode))
data_NL_pits <- filter(data_NL_pits, !duplicated(data_NL_pits$labcode))
data_BE_pits <- filter(data_BE_pits, !duplicated(data_BE_pits$labcode))
data_DE_pits$sample <- NA
data_NL_pits$source_id <- 1:nrow(data_NL_pits)
data_NL_pits$cs <- "WGS"
data_BE_pits$region <- NULL
data_NL_pits <- data_NL_pits%>%
  select(
    source = source,
    source_id = source_id,
    wgslat = wgslat,
    wgslon = wgslon,
    country = country,
    site = sitename,
    labcode = labcode,
    method = method,
    c14age = c14age,
    c14sd = c14sd,
    c13 = c13,
    material = material,
    sample = sample,
    feature = feature,
    species = species,
    description = `context info`,
    period = period,
    culture = culture,
    reference = reference,
    comments = comments,
    cs = cs,
    loc_csx = X_RD,
    loc_csy = Y_RD)  
  
data_pits <- rbind(data_DE_pits,
data_NL_pits,data_BE_pits)

data_pits <- data_pits%>%filter(c14sd<=250)
data_pits <- data_pits%>%filter(wgslat>=50)
data_pits <- data_pits%>%filter(wgslon<=10)
max(data_pits$c14sd)


path <- "data/data_pits.xlsx"
write.xlsx(data_pits, file=path)

#################################################################
# intersite distance
################################################################
require(spatstat)
d<-function(coord) {
  # Calculate distances between all sets of sites with dates in the window
  dd<-pairdist(X=coord[,1], Y=coord[,2])
  dd<-dd[upper.tri(dd)]
  # Exclude any cases of two or more dates from the same site
  dd<-dd[dd>0]
  return(dd)
}

data_pits <- data_pits%>%filter(!is.na(wgslat))
data_pits <- data_pits%>%filter(!is.na(wgslon))
data_pits <- data_pits%>%filter(c14sd<=250)
data_pits$Calcurve="intcal"

data_pits.rc <- rowcal(date=data_pits$c14age,
                sigma=data_pits$c14age,
                cc=data_pits$Calcurve)
data_pits$median=findmedian(data_pits.rc)
data_pits$median=data_pits$median*-1
##################################################################################
par(mfrow=c(3,1))
data <- data_pits
dists<-c()
counter<- 1
from <- 6000 # start date
to <- 12500 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)
for(Y in seq(from=from,to=to,by=by)) {
  dists[counter]<-mean(
    d(data.frame(data$wgslon[data$median<Y & data$median>=Y-size],
                 data$wgslat[data$median<Y & data$median>=Y-size])
    ))
  counter<-counter+1
}
# Convert to km
#dists<-dists/1000


l<-loess(dists~years, span=0.15)
lp<-predict(l, se=TRUE)



plot(years, dists, pch='.', ylab='Mean intersite distance / km',
     xlab='Cal. BP', xlim=c(12500,6500), ylim=c(0,3), xaxs="i")
mtext("Pit hearths: intersite distance", side=3, line=0.1, adj=0)
axis(1, at = seq(6000,12000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(6500, 12500, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(6500,12500, by=100), labels = FALSE, tck=-0.015)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
source("scripts/phaserect-3.R")



##LAT


lat<-c()
counter<- 1
from <- 6000 # start date
to <- 12500 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)

for(Y in seq(from=from,to=to,by=by)) {
  lat[counter]<-mean(data$wgslat[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
# Convert to km
#dists<-dists/1000


l<-loess(lat~years, span=0.15)
lp<-predict(l, se=TRUE)

plot(years, lat, pch='.', ylab='Latitude',
     xlab='Cal. BP', xlim=c(12500,6500), ylim=c(51,54), xaxs="i")
mtext("Pit hearths: Latitude", side=3, line=0.1, adj=0)
axis(1, at = seq(6500,12000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(6500, 12000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(6500,12500, by=100), labels = FALSE, tck=-0.015)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
source("scripts/phaserect-3.R")



##lon

lon<-c()
counter<- 1
from <- 6500 # start date
to <- 12500 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)

for(Y in seq(from=from,to=to,by=by)) {
  lon[counter]<-mean(data$wgslon[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
# Convert to km
#dists<-dists/1000


l<-loess(lon~years, span=0.15)
lp<-predict(l, se=TRUE)

plot(years, lon, pch='.', ylab='Longitude',
     xlab='Cal. BP', ylim=c(4,10),xlim=c(12500,6500), xaxs="i")
mtext("Pit hearths: Longitude", side=3, line=0.1, adj=0)
axis(1, at = seq(6500,12000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(6500, 12000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(6500,12500, by=100), labels = FALSE, tck=-0.015)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
source("scripts/phaserect-3.R")

################################################################
#NL
################################################################
##LAT
data <- data_pits%>%filter(country=="Netherlands")
lat<-c()
counter<- 1
from <- 6000 # start date
to <- 12000 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)

for(Y in seq(from=from,to=to,by=by)) {
  lat[counter]<-mean(data$wgslat[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
# Convert to km
#dists<-dists/1000


l<-loess(lat~years, span=0.15)
lp<-predict(l, se=TRUE)

plot(years, lat, pch='.', ylab='Latitude',
     xlab='Cal. BP', xlim=c(12000,6000))
mtext("Pit hearths Netherlands", side=3, line=0.1, adj=0)
axis(1, at = seq(6000,12000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(6000, 12000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(6000,12000, by=100), labels = FALSE, tck=-0.015)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
source("scripts/phaserect.R")



##lon

lon<-c()
counter<- 1
from <- 6000 # start date
to <- 12000 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)

for(Y in seq(from=from,to=to,by=by)) {
  lon[counter]<-mean(data$wgslon[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
# Convert to km
#dists<-dists/1000


l<-loess(lon~years, span=0.15)
lp<-predict(l, se=TRUE)

plot(years, lon, pch='.', ylab='Longitude',
     xlab='Cal. BP', ylim=c(4,10),xlim=c(12000,6000))
mtext("Pit hearths Netherlands", side=3, line=0.1, adj=0)
axis(1, at = seq(6000,12000, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(6000, 12000, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(6000,12000, by=100), labels = FALSE, tck=-0.015)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
source("scripts/phaserect.R")

