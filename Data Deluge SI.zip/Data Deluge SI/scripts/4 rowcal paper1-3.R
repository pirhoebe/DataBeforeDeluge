source("scripts/read libraries.R")
#rowcal
Paper1<- read_excel("data/Supplementary dataset vetted.xlsx")
SupMat_dataset <- read_excel("data/SupMat dataset.xlsx")

Paper1 <- left_join(Paper1, SupMat_dataset[,c("site","wgslon", "wgslat")], 
                    by="site",
                    multiple = "first")
Paper2 <- read_excel("data/data24cal.xlsx")

Paper3<- read_excel("data/data FINAL (19-12-2024).xlsx")
Paper1 <- Paper1%>%rename(sitename="site")
Paper1 <- filter(Paper1, !duplicated(Paper1$labcode))
Paper2 <- filter(Paper2, !duplicated(Paper2$labcode))
Paper3 <- filter(Paper3, !duplicated(Paper3$labcode))

Paper1 <- filter(Paper1, c14sd<=250)
Paper1 <- filter(Paper1, !is.na(c14sd))
Paper1 <- filter(Paper1, !is.na(c14age))
Paper1 <- filter(Paper1, !is.na(sitename))
Paper1 <- filter(Paper1, c14age<=14000)
Paper1 <- filter(Paper1, c14age>=5000)
Paper2 <- filter(Paper2, c14sd<=250)
Paper2 <- filter(Paper2, !is.na(c14sd))
Paper2 <- filter(Paper2, !is.na(c14age))
Paper3 <- filter(Paper3, c14sd<=250)
Paper3 <- filter(Paper3, !is.na(c14sd))

Paper2W <- Paper2%>%filter(RA=="WEST")
Paper2E <- Paper2%>%filter(RA=="EAST")

##############################################################
# PARAMETERS 
ncores <- 3 # set the number of processor cores that you want to set to work.
curve <- "intcal20"
normalised <- FALSE # turn of redundant normalisation

# calibration
set <- Paper1
source("scripts/calibrate data.R")
Paper1_full.cal <- set.cal
rm(set, set.cal)

# # seperate the vetted Paper1set
# Paper1_vet.cal <- Paper1_full.cal[Paper1_full.cal$metaPaper1$vet==1]


###############################################################################
#### 1.3 appending calibrated date ranges to Paper1set ####
###############################################################################

# add calBP start and end to the main Paper1set for further selection purposes
# create Paper1frame with the calibrated from - to Paper1. 
calsum <- summary(Paper1_full.cal)

# extracting the full two sigma calibrated range from calsum
calsum <- select(calsum, "DateID", "MedianBP",starts_with("TwoSigma"))

# splitting the date ranges of all the individual peaks in each date 
# distribution into a start date and an end date
calsum <- calsum %>% 
  separate(TwoSigma_BP_1, c("Two_sigma_1_start", "Two_sigma_1_end"), " to ")%>% 
  separate(TwoSigma_BP_2, c("Two_sigma_2_start", "Two_sigma_2_end"), " to ")%>% 
  separate(TwoSigma_BP_3, c("Two_sigma_3_start", "Two_sigma_3_end"), " to ")%>% 
  separate(TwoSigma_BP_4, c("Two_sigma_4_start", "Two_sigma_4_end"), " to ")%>% 
  separate(TwoSigma_BP_5, c("Two_sigma_5_start", "Two_sigma_5_end"), " to ")%>% 
  separate(TwoSigma_BP_6, c("Two_sigma_6_start", "Two_sigma_6_end"), " to ")%>% 
  separate(TwoSigma_BP_7, c("Two_sigma_7_start", "Two_sigma_7_end"), " to ")%>%
  separate(TwoSigma_BP_8, c("Two_sigma_8_start", "Two_sigma_8_end"), " to ")

calsum[calsum=="NA"] <- NA

# earliest date in column 1
calsum$calBP_first <- calsum$Two_sigma_1_start
# latest date in columns 2 to 9
calsum$calBP_last <- calsum$Two_sigma_8_end
calsum$calBP_last[is.na(calsum$calBP_last)] <- 
  calsum$Two_sigma_7_end[is.na(calsum$calBP_last)]
calsum$calBP_last[is.na(calsum$calBP_last)] <- 
  calsum$Two_sigma_6_end[is.na(calsum$calBP_last)]
calsum$calBP_last[is.na(calsum$calBP_last)] <- 
  calsum$Two_sigma_5_end[is.na(calsum$calBP_last)]
calsum$calBP_last[is.na(calsum$calBP_last)] <- 
  calsum$Two_sigma_4_end[is.na(calsum$calBP_last)]
calsum$calBP_last[is.na(calsum$calBP_last)] <- 
  calsum$Two_sigma_3_end[is.na(calsum$calBP_last)]
calsum$calBP_last[is.na(calsum$calBP_last)] <- 
  calsum$Two_sigma_2_end[is.na(calsum$calBP_last)]
calsum$calBP_last[is.na(calsum$calBP_last)] <- 
  calsum$Two_sigma_1_end[is.na(calsum$calBP_last)]

caldates <- Paper1_full.cal$metadata
caldates <- left_join(x=caldates, 
                      y=calsum[ , c("DateID","calBP_first", "calBP_last")], 
                      by = c("DateID"="DateID"))
caldates$calBP_start <- as.numeric(caldates$calBP_first)
caldates$calBP_end <- as.numeric(caldates$calBP_last)


# append Paper1set with calBP start and end
caldates$DateID <- as.numeric(caldates$DateID)
Paper1 <- left_join(x=Paper1, 
                         y=caldates[ , c("DateID","calBP_start", "calBP_end")], 
                         by = c("ID"="DateID"))
rm(caldates, calsum)
Paper1$dlength=Paper1$calBP_start-Paper1$calBP_end
Paper1$median1=(Paper1$calBP_start+Paper1$calBP_end)/2
rm(Paper1_full.cal)
Paper2$median1=(Paper2$calBP_start+Paper2$calBP_end)/2
Paper3$median1=(Paper3$calBP_start+Paper3$calBP_end)/2

Paper1$rowcaldiff <- (Paper1$median*-1)-Paper1$median1

plot(Paper1$c14age, Paper1$rowcaldiff, type="p")
plot(Paper1$c14age, Paper1$dlength, type="p")

Paper3$rowcaldiff <- (Paper3$median*-1)-Paper3$median1
plot(Paper3$c14age, Paper3$rowcaldiff, type="p")
plot(Paper3$c14age, Paper3$dlength, type="p")
#############################################################
# ROWCAL CODE
library("rowcal")

## PAPER 1
Paper1$Calcurve <- 'intcal20'

Paper1.rc <- rowcal(date=Paper1$c14age,
                    sigma=Paper1$c14age,
                    cc=Paper1$Calcurve,
                    BC=TRUE)
Paper1$median=findmedian(Paper1.rc)
Paper1_kde<-mixdensity(data.frame(c14age=Paper1$c14age,
                                  c14sd=Paper1$c14sd,
                                  Calcurve=Paper1$Calcurve),
                       bw=100)
?phasedensity()
Paper1_kdep <- phasedensity(siteids = Paper1$sitename,
                            dates = Paper1.rc,
                            dl= data.frame(Paper1$sitename,
                                           c14age=Paper1$c14age,
                                           c14sd=Paper1$c14sd,
                                           Calcurve=Paper1$Calcurve),
                            
                            bw=100)
beep(4)


## PAPER 2 West
Paper2W$Calcurve <- 'intcal20'

Paper2W.rc <- rowcal(date=Paper2W$c14age,
                    sigma=Paper2W$c14age,
                    cc=Paper2W$Calcurve,
                    BC=TRUE)
Paper2W$median=findmedian(Paper2W.rc)
Paper2W_kde<-mixdensity(data.frame(c14age=Paper2W$c14age,
                                  c14sd=Paper2W$c14sd,
                                  Calcurve=Paper2W$Calcurve),
                       bw=100)

Paper2W_kdep <- phasedensity(siteids = Paper2W$sitename,
                            dates = Paper2W.rc,
                            dl= data.frame(Paper2W$sitename,
                                           c14age=Paper2W$c14age,
                                           c14sd=Paper2W$c14sd,
                                           Calcurve=Paper2W$Calcurve),
                            
                            bw=100)
beep(4)
growth_mod<-ggr(Paper2W_kdep)


## PAPER 2 East
Paper2E$Calcurve <- 'intcal20'

Paper2E.rc <- rowcal(date=Paper2E$c14age,
                    sigma=Paper2E$c14age,
                    cc=Paper2E$Calcurve,
                    BC=TRUE)
Paper2E$median=findmedian(Paper2E.rc)
Paper2E_kde<-mixdensity(data.frame(c14age=Paper2E$c14age,
                                  c14sd=Paper2E$c14sd,
                                  Calcurve=Paper2E$Calcurve),
                       bw=100)

Paper2E_kdep <- phasedensity(siteids = Paper2E$sitename,
                            dates = Paper2E.rc,
                            dl= data.frame(Paper2E$sitename,
                                           c14age=Paper2E$c14age,
                                           c14sd=Paper2E$c14sd,
                                           Calcurve=Paper2E$Calcurve),
                            
                            bw=100)
beep(4)
growth_mod<-ggr(Paper2E_kdep)


## PAPER 1
Paper3$Calcurve <- 'intcal20'

Paper3.rc <- rowcal(date=Paper3$c14age,
                    sigma=Paper3$c14age,
                    cc=Paper3$Calcurve,
                    BC=TRUE)
Paper3$median=findmedian(Paper3.rc)
Paper3_kde<-mixdensity(data.frame(c14age=Paper3$c14age,
                                  c14sd=Paper3$c14sd,
                                  Calcurve=Paper3$Calcurve),
                       bw=100)

Paper3_kdep <- phasedensity(siteids = Paper3$sitename,
                            dates = Paper3.rc,
                            dl= data.frame(Paper3$sitename,
                                           c14age=Paper3$c14age,
                                           c14sd=Paper3$c14sd,
                                           Calcurve=Paper3$Calcurve),
                            
                            bw=100)
beep(4)


# Derive dynamic growth model from KDE of phase density, highlight phases of statistically significant growth
# or decline

par(mfrow=c(2,1))
par(mar=c(2,4.1,1.5,1))
par(oma=c(2,0,2,0))
# Paper 1

growth_mod<-ggr(Paper1_kdep)
plot(Paper1_kdep,  col=rgb(0,0,0,0.1),fill=rgb(0,0,0,0.3), xlim=c(-14000,-4000),
     ylim=c(0,0.0004),xaxt="n",xlab=NA, grid=FALSE)
mtext(" a. Chapter II vetted KDE n=3626", line=-1.2, adj=0, cex=1)
# plot(Paper1_kde, col=rgb(0,0,0,0.3), lty=3,add=T)
# legend(x=-14000, y=0.00045,lty=c(1,3),lwd=c(1,2),
#        legend=c('Unique phases','All dates'),bty='n')
# axis(1, at=seq(16000, 6000, by=-1000), labels=TRUE, tck=-0.05)
# axis(1, at=seq(16000, 6000, by=-500), labels=FALSE, tck=-0.03)
# axis(1, at=seq(16000, 6000, by=-100), labels=FALSE, tck=-0.01)
axis(1, at=seq(-14050, -4050, by=2000), labels=seq(16000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-14050, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-14050, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-14050, -4050, by=100), labels=FALSE, tck=-0.01)
lines(median(Paper1_kdep))
growthmod_dev<- ggrsignif(growth_mod)
abline(v=growthmod_dev$year[growthmod_dev$sig_high==TRUE],
       col=rgb(1,0,0,0.1), lwd=2)
abline(v=growthmod_dev$year[growthmod_dev$sig_low==TRUE],
       col=rgb(0,0,1,0.1), lwd=2)
rowcalBC=1
phaselabels=TRUE
ppos=-0.25
phasepl=2
source("scripts/phaserect.R")
# phasepl=2
# source("scripts/phaserect.R")

plot(growth_mod, fill=rgb(0,0,0,0.3), col=1, xlim=c(-14000,-4000),
     ylim=c(-0.7,0.7),xaxt='n')
mtext(" b. Chapter II growth model", line=-1.2, adj=0, cex=1)
abline(h=0)
axis(1, at=seq(-14050, -4050, by=2000), labels=seq(16000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-14050, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-14050, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-14050, -4050, by=100), labels=FALSE, tck=-0.01)
rowcalBC=1
rm(phaselabels)
phasepl=1
source("scripts/phaserect.R")

#########################################
# HOLOCENE
#______________________________________________________________
par(mfrow=c(3,2))
par(mar=c(2,4.1,1.5,1))
par(oma=c(2,0,3,0))
growth_mod<-ggr(Paper2W_kdep)
plot(Paper2W_kdep,  col=rgb(0,0,0,0.1),fill=rgb(0,0,0,0.3), xlim=c(-10550,-4050),
     ylim=c(0,0.0005),xaxt='n',xlab=NA, grid=FALSE)
mtext("a. KDE models with significant roc", line=3, adj=0, cex=1)
mtext("   Chapter IV West KDE n=573", line=-1.2, adj=0, cex=0.8)
# plot(Paper2W_kde, col=rgb(0,0,0,0.3), lty=3,add=T)
# legend(x=-14000, y=0.00045,lty=c(1,3),lwd=c(1,2),
#        legend=c('Unique phases','All dates'),bty='n')
axis(1, at=seq(-10050, -4050, by=2000), labels=seq(12000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-10550, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-10550, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-10550, -4050, by=100), labels=FALSE, tck=-0.01)
lines(median(Paper2W_kdep))
growthmod_dev<- ggrsignif(growth_mod)
abline(v=growthmod_dev$year[growthmod_dev$sig_high==TRUE],
       col=rgb(1,0,0,0.1))
abline(v=growthmod_dev$year[growthmod_dev$sig_low==TRUE],
       col=rgb(0,0,1,0.1))
rowcalBC=1
phaselabels=TRUE
ppos=-0.25
phasepl=2
source("scripts/phaserect2.R")

plot(growth_mod, fill=rgb(0,0,0,0.3), col=1, xlim=c(-10550,-4050),
     ylim=c(-0.7,0.7),xaxt='n')

mtext("b. rate of change growth model test", line=3, adj=0, cex=1)
mtext("   Chapter IV West growth model", line=-1.2, adj=0, cex=0.8)
abline(h=0)
axis(1, at=seq(-10050, -4050, by=2000), labels=seq(12000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-10550, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-10550, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-10550, -4050, by=100), labels=FALSE, tck=-0.01)
rowcalBC=1
phaselabels=TRUE
ppos=-0.25
phasepl=2
source("scripts/phaserect2.R")
phasepl=1
rm(phaselabels)
source("scripts/phaserect2.R")
#______________________________________________________________

growth_mod<-ggr(Paper2E_kdep)
plot(Paper2E_kdep, col=rgb(0,0,0,0.1),fill=rgb(0,0,0,0.3), xlim=c(-10550,-4050),
     ylim=c(0,0.0005),xaxt='n',xlab=NA, grid=FALSE)
mtext("   Chapter IV East KDE n=2479", line=-1.2, adj=0, cex=0.8)
# plot(Paper2E_kde, col=rgb(0,0,0,0.3), lty=3,add=T)
# legend(x=-14000, y=0.00045,lty=c(1,3),lwd=c(1,2),
#        legend=c('Unique phases','All dates'),bty='n')
axis(1, at=seq(-10050, -4050, by=2000), labels=seq(12000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-10550, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-10550, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-10550, -4050, by=100), labels=FALSE, tck=-0.01)
lines(median(Paper2E_kdep))
growthmod_dev<- ggrsignif(growth_mod)
abline(v=growthmod_dev$year[growthmod_dev$sig_high==TRUE],
       col=rgb(1,0,0,0.1))
abline(v=growthmod_dev$year[growthmod_dev$sig_low==TRUE],
       col=rgb(0,0,1,0.1))
rowcalBC=1
rm(phaselabels)
phasepl=2
source("scripts/phaserect2.R")

plot(growth_mod, fill=rgb(0,0,0,0.3), col=1, xlim=c(-10550,-4050),
     ylim=c(-0.7,0.7),xaxt='n')
mtext("   Chapter IV East growth model", line=-1.2, adj=0, cex=0.8)
abline(h=0)
axis(1, at=seq(-10050, -4050, by=2000), labels=seq(12000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-10550, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-10550, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-10550, -4050, by=100), labels=FALSE, tck=-0.01)
rowcalBC=1
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")
#______________________________________________________________

growth_mod<-ggr(Paper3_kdep)
plot(Paper3_kdep, col=rgb(0,0,0,1), fill=rgb(0,0,0,0.3), xlim=c(-10550,-4050),
     ylim=c(0,0.0005),xaxt='n',xlab=NA, grid=FALSE)
mtext("   Chapter V KDE n=1291", line=-1.2, adj=0, cex=0.8)
# plot(Paper3_kde, col=rgb(0,0,0,0.3), lty=3,add=T)
# legend(x=-14000, y=0.00045,lty=c(1,3),lwd=c(1,2),
#        legend=c('Unique phases','All dates'),bty='n')
axis(1, at=seq(-10050, -4050, by=2000), labels=seq(12000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-10550, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-10550, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-10550, -4050, by=100), labels=FALSE, tck=-0.01)
lines(median(Paper3_kdep))
growthmod_dev<- ggrsignif(growth_mod)
abline(v=growthmod_dev$year[growthmod_dev$sig_high==TRUE],
       col=rgb(1,0,0,0.1))
abline(v=growthmod_dev$year[growthmod_dev$sig_low==TRUE],
       col=rgb(0,0,1,0.1))
rowcalBC=1
rm(phaselabels)
phasepl=2
source("scripts/phaserect2.R")

plot(growth_mod, fill=rgb(0,0,0,0.3), col=1, xlim=c(-10550,-4050),
     ylim=c(-0.7,0.7),xaxt='n')
mtext("   Chapter V growth model", line=-1.2, adj=0, cex=0.8)
abline(h=0)
axis(1, at=seq(-10050, -4050, by=2000), labels=seq(12000,6000,by=-2000), tck=-0.05)
axis(1, at=seq(-10550, -4050, by=1000), labels=FALSE, tck=-0.05)
axis(1, at=seq(-10550, -4050, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-10550, -4050, by=100), labels=FALSE, tck=-0.01)
rowcalBC=1
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")

