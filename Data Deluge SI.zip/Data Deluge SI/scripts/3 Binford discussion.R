install.packages("car")
library(car)
source("scripts/read libraries.R")
install.packages("binford")
library(binford)

load("data/LRBfact.rdata")
LRB <- LRB
LRBkey  <- LRBkey


levels(as.factor(LRBfact$vegclass))

LRBsel <- LRBfact%>%filter(vegclass %in% c("Tundra", "Cold Needleleaf Forests",
                                           "Coastal Forest","Mid-Latitude Deciduous Forest"))
LRBsel$vegclass <- factor(LRBsel$vegclass, levels= c("Tundra", "Cold Needleleaf Forests",
                                                     "Mid-Latitude Deciduous Forest", "Coastal Forest"),
                          labels=c("Tundra", "Boreal forest", "Deciduous forest", "Coastal forest"),
                          ordered= TRUE)

LRBsel$qtstor <- factor(LRBsel$qtstor,
                        levels=c("Minor",    "Moderate",
                                 "Major",    "Massive"),
                        labels=c("-", "+", "++", "+++"),
                        ordered=TRUE)
LRBsel$store <- factor(LRBsel$store,
                       levels=c("Not present",    "Special event storage only",
                                "Stored for use during seasonal and/or other low productivity phases of year"),
                       labels=c("None", "Events", "Seasonal"),
                       ordered=TRUE)


LRBsel$sed <- factor(LRBsel$sed,
                     levels=c("Fully nomadic", "Semi-nomadic",         
                              "Semi-sedentary","Seasonal permanence"),
                     ordered=TRUE)

par(mfrow=c(1,1))
# pop density by regime                          
plot(x=LRBsel$kmov,
     y=LRBsel$density, type="p")


# pop density by regime                          
plot(x=LRBsel$vegclass,
     y=LRBsel$density, type="p")

plot(x=LRBsel$vegclass,
     y=LRBsel$group1, type="p")
plot(x=LRBsel$vegclass,
     y=LRBsel$group3, type="p")
plot(x=LRBsel$vegclass,
     y=LRBsel$group2, type="p", ylim=c(0,300))

#NAGP ####
# nagp by regime
plot(x=LRBsel$vegclass,
     y=LRBsel$nagp, type="p")
# pop dens by nagp
plot(x=LRBsel$nagp,
     y=LRBsel$density, type="p", col=LRBsel$vegclass)

lines(lowess(LRBsel$nagp,
             LRBsel$density), col="red")
cor.test(LRBsel$density,
                  LRBsel$nagp)

#npp ####
# npp by regime
plot(x=LRBsel$vegclass,
     y=LRBsel$npp, type="p")
# pop dens by npp
plot(x=LRBsel$npp[LRBsel$npp<1],
     y=LRBsel$density[LRBsel$npp<1], type="p", col=LRBsel$vegclass)
lines(lowess(LRBsel$npp[LRBsel$npp<1],
             LRBsel$density[LRBsel$npp<1]), col="red")


# ET ####
# et by regime
plot(x=LRBsel$vegclass,
     y=LRBsel$et, type="p")
plot(x=LRBsel$et,
     y=LRBsel$density, type="p", col=LRBsel$vegclass)
lines(lowess(LRBsel$et,
             LRBsel$density), col="red")

# PRECIP SEASONALITY ####
# bio.15 (precip seasonality) by regime
plot(x=LRBsel$vegclass,
     y=LRBsel$bio.15, type="p")
plot(x=LRBsel$bio.15,
     y=LRBsel$density, type="p", col=LRBsel$vegclass)
lines(lowess(LRBsel$bio.15,
             LRBsel$density), col="red")

cor.test(LRBsel$density,
         LRBsel$bio.15)

# cultural choicbio.15# cultural choices ####
# distance to coast
plot(x=LRBsel$dicgsh1a*-1,
     y=LRBsel$density, type="p",  pch=19,
     col=plotcolors[factor(LRBsel$subsp)])
lines(lowess(LRBsel$dicgsh1a*-1,
             LRBsel$density), col="red")

# number of moves
plot(x=LRBsel$nomov[!is.na(LRBsel$nomov)],
     y=LRBsel$density[!is.na(LRBsel$nomov)], type="p", pch=19,
     col=plotcolors[factor(LRBsel$subsp)])
lines(lowess(LRBsel$nomov[!is.na(LRBsel$nomov)],
             LRBsel$density[!is.na(LRBsel$nomov)]), col="red")

# distance moved
plot(x=LRBsel$kmov[!is.na(LRBsel$kmov)],
     y=LRBsel$density[!is.na(LRBsel$kmov)], type="p", pch=19,
     col=plotcolors[factor(LRBsel$subsp)])
lines(lowess(LRBsel$kmov[!is.na(LRBsel$kmov)],
             LRBsel$density[!is.na(LRBsel$kmov)]), col="red")

# Averge distance per move (in km)
plot(x=LRBsel$kspmov[!is.na(LRBsel$kspmov)],
     y=LRBsel$density[!is.na(LRBsel$kspmov)], type="p", col=LRBsel$vegclass)
lines(lowess(LRBsel$kspmov[!is.na(LRBsel$kspmov)],
             LRBsel$density[!is.na(LRBsel$kspmov)]), col="red")

# Averge distance per move (in km)
plotcolors <- c("cyan4", "chartreuse4", "firebrick")
plot(x=LRBsel$kspmov[!is.na(LRBsel$kspmov)],
     y=LRBsel$density[!is.na(LRBsel$kspmov)], type="p", pch=19,
     col=plotcolors[factor(LRBsel$subsp)])

lines(lowess(LRBsel$kspmov[!is.na(LRBsel$kspmov)],
             LRBsel$density[!is.na(LRBsel$kspmov)]), col="red")


# BINFORD PLOT 
plotcolors <- c("cyan4", "chartreuse4", "firebrick")
layout.matrix <- matrix(c(1:6), nrow=3, ncol=2)
layout.matrix
layout(mat=layout.matrix, 
       heights=c(2,2,2),
       widths=c(3,2))
# par(mfrow=c(3,2))
par(mar=c(4,4,2,1))
# nomov
plot(x=LRBsel$nomov[!is.na(LRBsel$nomov)],
     y=LRBsel$density[!is.na(LRBsel$nomov)], type="p", pch=19,
     xlab="number of moves",
     ylab="population density",
     col=plotcolors[factor(LRBsel$subsp)])
legend("topright",
       col=plotcolors,
       pch=19,
       legend=c("Aquatics",  "Gathering", "Hunting"),
       title="Subsistence focus", title.font=2)
mtext("b. Number of moves:", side=3, line=0.1, adj=0)

# distance moved
plot(x=LRBsel$kmov[!is.na(LRBsel$kmov)],
     y=LRBsel$density[!is.na(LRBsel$kmov)], type="p", pch=19,
     ylab="population density",
     xlab="annual residential mobility (km)",
     col=plotcolors[factor(LRBsel$subsp)])
mtext("c. Residential Mobility per year:", side=3, line=0.1, adj=0)

# distance to coast
plot(x=LRBsel$dicgsh1a*-1,
     ylab="population density",
     xlim=c(0,1200),
     xlab="distance to the coast (km)",
     y=LRBsel$density, type="p",  pch=19,
     col=plotcolors[factor(LRBsel$subsp)])
mtext("d. Distance to coast:", side=3, line=0.1, adj=0)
# Storage ####


plot(x=LRBsel$vegclass,
     y=LRBsel$density, type="p",
     ylab="population density",
     xlab= "biome")
mtext("e. Biome:", side=3, line=0.1, adj=0)
plot(x=LRBsel$store,
     y=LRBsel$density, type="p",
     ylab="population density",
     xlab= "storage")
mtext("f. Dependence on storage:", side=3, line=0.1, adj=0)
plot(x=LRBsel$qtstor,
     y=LRBsel$density, type="p",
     ylab="population density",
     xlab= "storage quantity")
mtext("g. Quantity of stored food:", side=3, line=0.1, adj=0)


plot(x=LRBsel$sed,
     y=LRBsel$density, type="p")
plot(x=LRBsel$sed,
     y=LRBsel$nomov, type="p")
plot(x=LRBsel$sed,
     y=LRBsel$kspmov, type="p")

plot(x=LRBsel$sed,
     y=LRBsel$qtstor,
     xlab="sedentism",
     ylab="storage quantity",type="p")

# Fishing, Hunting, Gathering
plot(x=LRBsel$fishing,
     y=LRBsel$density, type="p", col=LRBsel$vegclass)
lines(lowess(LRBsel$fishing,
             LRBsel$density), col="red")
plot(x=LRBsel$hunting,
     y=LRBsel$density, type="p", col=LRBsel$vegclass)
lines(lowess(LRBsel$hunting,
             LRBsel$density), col="red")
plot(x=LRBsel$gatherin,
     y=LRBsel$density, type="p", col=LRBsel$vegclass)
lines(lowess(LRBsel$gatherin,
             LRBsel$density), col="red")


# carplot popdens by nagp
par(oma=c(2,2,2,2))
scatterplot(density~nagp , data = LRBsel[LRBsel$vegclass=="Tundra",])
scatterplot(density~nagp , data = LRBsel[LRBsel$vegclass=="Cold Needleleaf Forests",])
scatterplot(density~nagp , data = LRBsel[LRBsel$vegclass=="Mid-Latitude Deciduous Forest",])
scatterplot(density~nagp , data = LRBsel[LRBsel$vegclass=="Coastal Forest",])

scatterplot(density~nagp, data = LRBsel)

scatterplot(density~nagp | vegclass, data = LRBsel[LRBsel$sed%in%c("Nomadic","Semi-nomadic", "Semi-sedentary"),])
#et
scatterplot(density~et, data = LRBsel)

#seasonality precip 
scatterplot(density~bio.15 | vegclass, data = LRBsel)
# significant in coastal forest

densityPlot(x=LRBsel$density, g=LRBsel$vegclass)

LRBsel$vegclass <- factor(LRBsel$vegclass, levels=)
levels(LRBsel$vegclass)
TUdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Tundra"])
BFdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Cold Needleleaf Forests"])
CFdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Coastal Forest"],
                      g=LRBsel$sed[LRBsel$vegclass=="Coastal Forest"])
#______________________________________________________________________________
# PLOT ####
#______________________________________________________________________________
par(mfrow=c(3,1))
par(oma=c(1,1,1,1))
par(mar=c(2,3,3,1))
# TUNDRA ####
TUdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Tundra"],
                      ylim=c(0,max(TUdist$y*1.2)))
mtext(paste("Tundra population density, n cases =",nrow(LRBsel[LRBsel$vegclass=="Tundra",])),3, adj=0)
rect(xleft=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])-sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     xright=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])+sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     ybottom=-1,
     ytop=1, col=rgb(1,0,0,0.3), border=NA)
abline(v=mean(LRBsel$density[LRBsel$vegclass=="Tundra"]), col="red")
abline(v=TUdist$x[TUdist$y==max(TUdist$y)], col="blue")
text(x=TUdist$x[TUdist$y==max(TUdist$y)],
     y=1.1*max(TUdist$y),
     labels=paste("Mo =",round(TUdist$x[TUdist$y==max(TUdist$y)],2)),
     adj=0.5)
text(x=mean(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     y=1.2*max(TUdist$y),
     labels=paste("M =",round(mean(LRBsel$density[LRBsel$vegclass=="Tundra"]),2)),
     adj=0.5)
text(x=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])+sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     y=1.1*max(TUdist$y),
     labels=paste("sd =",round(sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),2)),
     adj=0.5)

# Boreal forest ####
BFdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Boreal forest"],
                      ylim=c(0,max(BFdist$y*1.2)))
mtext(paste("Boreal forest population density, n cases =",nrow(LRBsel[LRBsel$vegclass=="Boreal forest",])),3, adj=0)
rect(xleft=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])-sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     xright=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])+sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     ybottom=-1,
     ytop=1, col=rgb(1,0,0,0.3), border=NA)
abline(v=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"]), col="red")
abline(v=BFdist$x[BFdist$y==max(BFdist$y)], col="blue")
text(x=BFdist$x[BFdist$y==max(BFdist$y)],
     y=1.1*max(BFdist$y),
     labels=paste("Mo =",round(BFdist$x[BFdist$y==max(BFdist$y)],2)),
     adj=0.5)
text(x=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     y=1.2*max(BFdist$y),
     labels=paste("M =",round(mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),2)),
     adj=0.5)
text(x=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])+sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     y=1.1*max(BFdist$y),
     labels=paste("sd =",round(sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),2)),
     adj=0.5)


# Coastal forest ####
CFdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Coastal forest"],
                      g=LRBsel$sed[LRBsel$vegclass=="Coastal forest"],
                      legend=list(location="topright",title="Degree of Sedentism"),
                      ylim=c(0,max(CFdist$`Seasonal permanence`$y*1.1)))
mtext(paste("Coastal forest population density, n cases =",nrow(LRBsel[LRBsel$vegclass=="Coastal forest",])),3,1.5, adj=0)
mtext(paste("Semi-sedentary groups, n cases =",nrow(LRBsel[LRBsel$vegclass=="Coastal forest"&
                                                           LRBsel$sed=="Semi-sedentary",])),3,0, adj=0)
rect(xleft=mean(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                                 LRBsel$sed!="Seasonal permanence"])-
       sd(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                           LRBsel$sed!="Seasonal permanence"]),
     xright=mean(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                                  LRBsel$sed!="Seasonal permanence"])+
       sd(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                           LRBsel$sed!="Seasonal permanence"]),
     ybottom=-1,
     ytop=1, col=rgb(1,0,0,0.3), border=NA)
abline(v=mean(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                               LRBsel$sed!="Seasonal permanence"]), col="red")
# abline(v=CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y[CFdist$`Semi-sedentary`$x<35])], 
#   col="blue")
abline(v=CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y)], col="blue")


# text(x=CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y[CFdist$`Semi-sedentary`$x<35])],
#      y=1.5*max(CFdist$`Semi-sedentary`$y),
#      labels=paste("Mo1 =",round(CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y[CFdist$`Semi-sedentary`$x<35])],2)),
#      adj=0.5)
text(x=CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y)],
     y=1*max(CFdist$`Seasonal permanence`$y),
     labels=paste("Mo =",round(CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y)],2)),
     adj=0.5)

text(x=mean(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                             LRBsel$sed!="Seasonal permanence"]),
     y=1.1*max(CFdist$`Seasonal permanence`$y),
     labels=paste("M =",round(mean(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                                                    LRBsel$sed!="Seasonal permanence"]),2)),
     adj=0.5)
text(x=mean(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                             LRBsel$sed!="Seasonal permanence"])+sd(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                                                                              LRBsel$sed!="Seasonal permanence"]),
     y=1.1*max(CFdist$`Seasonal permanence`$y),
     labels=paste("sd =",round(sd(LRBsel$density[LRBsel$vegclass=="Coastal forest"&
                                                   LRBsel$sed!="Seasonal permanence"]),2)),
     adj=0.5)


#______________________________________________________________________________

#______________________________________________________________________________
# PLOT 1 x axis ####
#______________________________________________________________________________
par(mfrow=c(3,1))
par(oma=c(1,1,1,1))
par(mar=c(2,3,3,1))
# TUNDRA ####
TUdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Tundra"],
                      xlim=c(0,160),
                      ylim=c(0,max(TUdist$y*1.2)))
mtext(paste("Tundra population density, n cases =",nrow(LRBsel[LRBsel$vegclass=="Tundra",])),3, adj=0)
rect(xleft=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])-sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     xright=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])+sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     ybottom=-1,
     ytop=1, col=rgb(1,0,0,0.3), border=NA)
abline(v=mean(LRBsel$density[LRBsel$vegclass=="Tundra"]), col="red")
abline(v=TUdist$x[TUdist$y==max(TUdist$y)], col="blue")
text(x=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])+sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     y=1.2*max(TUdist$y),
     labels=paste("Mo =",round(TUdist$x[TUdist$y==max(TUdist$y)],2)),
     adj=0, col= "blue", cex=1.5)
text(x=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])+sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     y=1.1*max(TUdist$y),
     labels=paste("M =",round(mean(LRBsel$density[LRBsel$vegclass=="Tundra"]),2)),
     adj=0, col="red")
text(x=mean(LRBsel$density[LRBsel$vegclass=="Tundra"])+sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),
     y=1.0*max(TUdist$y),
     labels=paste("sd =",round(sd(LRBsel$density[LRBsel$vegclass=="Tundra"]),2)),
     adj=0, col="red")

# Boreal forest ####
BFdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass=="Boreal forest"],
                      xlim=c(0,160),
                      ylim=c(0,max(BFdist$y*1.2)))
mtext(paste("Boreal forest population density, n cases =",nrow(LRBsel[LRBsel$vegclass=="Boreal forest",])),3, adj=0)
rect(xleft=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])-sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     xright=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])+sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     ybottom=-1,
     ytop=1, col=rgb(1,0,0,0.3), border=NA)
abline(v=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"]), col="red")
abline(v=BFdist$x[BFdist$y==max(BFdist$y)], col="blue")
text(x=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])+sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     y=1.2*max(BFdist$y),
     labels=paste("Mo =",round(BFdist$x[BFdist$y==max(BFdist$y)],2)),
     adj=0, col="blue")
text(x=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])+sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     y=1.1*max(BFdist$y),
     labels=paste("M =",round(mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),2)),
     adj=0, col="red")
text(x=mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])+sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),
     y=1*max(BFdist$y),
     labels=paste("sd =",round(sd(LRBsel$density[LRBsel$vegclass=="Boreal forest"]),2)),
     adj=0, col= "red")


# Coastal forest ####
CFdist <- densityPlot(x=LRBsel$density[LRBsel$vegclass =="Coastal forest"],
                      g=LRBsel$sed[LRBsel$vegclass == "Coastal forest"],
                      legend=list(location="topright",title="Degree of Sedentism"),
                      xlim=c(0,160),
                      ylim=c(0,max(CFdist$`Seasonal permanence`$y*1.2)))
mtext(paste("Coastal forest population density, n cases =",nrow(LRBsel[LRBsel$vegclass =="Coastal forest",])),3,1.5, adj=0)
mtext(paste("Semi-sedentary groups, n cases =",nrow(LRBsel[LRBsel$vegclass =="Coastal forest"&
                                                             LRBsel$sed=="Semi-sedentary",])),3,0, adj=0)
rect(xleft=mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                 LRBsel$sed!="Seasonal permanence"])-
       sd(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                           LRBsel$sed!="Seasonal permanence"]),
     xright=mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                  LRBsel$sed!="Seasonal permanence"])+
       sd(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                           LRBsel$sed!="Seasonal permanence"]),
     ybottom=-1,
     ytop=1, col=rgb(1,0,0,0.3), border=NA)
abline(v=mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                               LRBsel$sed!="Seasonal permanence"]), col="red")
# abline(v=CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y[CFdist$`Semi-sedentary`$x<35])], 
#   col="blue")
abline(v=CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y)], col="blue")


# text(x=CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y[CFdist$`Semi-sedentary`$x<35])],
#      y=1.5*max(CFdist$`Semi-sedentary`$y),
#      labels=paste("Mo1 =",round(CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y[CFdist$`Semi-sedentary`$x<35])],2)),
#      adj=0.5)
text(x=mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                             LRBsel$sed!="Seasonal permanence"])+sd(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                                                                     LRBsel$sed!="Seasonal permanence"]),
     y=1.2*max(CFdist$`Seasonal permanence`$y),
     labels=paste("Mo =",round(CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y)],2)),
     adj=0, col="blue")

text(x=mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                             LRBsel$sed!="Seasonal permanence"])+sd(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                                                                     LRBsel$sed!="Seasonal permanence"]),
     y=1.1*max(CFdist$`Seasonal permanence`$y),
     labels=paste("M =",round(mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                                    LRBsel$sed!="Seasonal permanence"]),2)),
     adj=0, col= "red")
text(x=mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                             LRBsel$sed!="Seasonal permanence"])+sd(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                                                                     LRBsel$sed!="Seasonal permanence"]),
     y=1.0*max(CFdist$`Seasonal permanence`$y),
     labels=paste("sd =",round(sd(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                                   LRBsel$sed!="Seasonal permanence"]),2)),
     adj=0, col="red")


#______________________________________________________________________________

popmodel<- data.frame(calBP=16000:6000,
           regime=NA_character_,
           mode=NA,
           mean=NA,
           sd=NA)
popmodel$regime[popmodel$calBP>=13500] <- "Tundra"
popmodel$regime[popmodel$calBP>=11300 & popmodel$calBP<12500] <- "Tundra"
popmodel$regime[popmodel$calBP<13500 & popmodel$calBP>=12500] <- "Boreal forest"
popmodel$regime[popmodel$calBP<11300 & popmodel$calBP>=9500] <- "Boreal forest"
popmodel$regime[popmodel$calBP<9500] <- "Coastal forest"

popmodel$mode[popmodel$regime=="Tundra"] <- TUdist$x[TUdist$y==max(TUdist$y)]
popmodel$mean[popmodel$regime=="Tundra"] <- mean(LRBsel$density[LRBsel$vegclass=="Tundra"])
popmodel$sd[popmodel$regime=="Tundra"] <- sd(LRBsel$density[LRBsel$vegclass])

popmodel$mode[popmodel$regime=="Boreal forest"] <- BFdist$x[BFdist$y==max(BFdist$y)]
popmodel$mean[popmodel$regime=="Boreal forest"] <- mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])
popmodel$sd[popmodel$regime=="Boreal forest"] <- sd(LRBsel$density[LRBsel$vegclass])

popmodel$mode[popmodel$regime=="Coastal forest"] <- CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y)]
popmodel$mean[popmodel$regime=="Coastal forest"] <- mean(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                                                          LRBsel$sed!="Seasonal permanence"])
popmodel$sd[popmodel$regime=="Coastal forest"] <- sd(LRBsel$density[LRBsel$vegclass =="Coastal forest"&
                                                              LRBsel$sed!="Seasonal permanence"])
par(mfrow=c(1,1))
plot(x=popmodel$calBP, y=popmodel$mean+popmodel$sd, 
     xlim=c(16000,6000), ylim=c(0,110),col="red", type="l", lty=2)
lines(x=popmodel$calBP, y=popmodel$mean, col="red", type="l")
lines(x=popmodel$calBP, y=popmodel$mean+popmodel$sd, col="red", type="l", lty=2)
lines(x=popmodel$calBP, y=popmodel$mean-popmodel$sd, col="red", type="l", lty=2)
lines(x=popmodel$calBP, y=popmodel$mode, col="blue", type="l")

par(mfrow=c(1,1))
# mean model
plot(lowess(popmodel$calBP,
            popmodel$mean+popmodel$sd, f=0.05), 
     xlim=c(16000,6000), ylim=c(0,110),col="red", type="l", lty=2)
polygon(x=c(16000:6000,6000:16000),
          y=c(lowess(popmodel$mean+popmodel$sd, f=0.05)$y,
              lowess(rev(popmodel$mean-popmodel$sd), f=0.05)$y),
        col=rgb(1,0,0,0.3), border=NA)

lines(lowess(popmodel$calBP,
             popmodel$mean, f=0.05), col="red")
lines(lowess(popmodel$calBP,
             popmodel$mean+popmodel$sd, f=0.05), col="red", type="l", lty=2)
lines(lowess(popmodel$calBP,
             popmodel$mean-popmodel$sd, f=0.05), col="red", type="l", lty=2)


#mode
plot(lowess(popmodel$calBP,
             popmodel$mode, f=0.05), col="blue",xlim=c(16000,6000), ylim=c(0,50), type="l")


#_______________________________________________________________________________

densityPlot(x=LRBsel$density[LRBsel$vegclass=="Boreal forest"])
mean(LRBsel$density[LRBsel$vegclass=="Boreal forest"])

densityPlot(x=LRBsel$density[LRBsel$vegclass =="Coastal forest"])
densityPlot(x=LRBsel$density[LRBsel$vegclass =="Coastal forest" &
                               LRBsel$density<60])
CFdist<- densityPlot(x=LRBsel$density[LRBsel$vegclass =="Coastal forest"])
CFdist <- data.frame(x=CFdist$`Semi-sedentary`$x,y=CFdist$`Semi-sedentary`$y)
CFdist$`Semi-sedentary`$x[CFdist$`Semi-sedentary`$y==max(CFdist$`Semi-sedentary`$y)]
scatterplot(density~dicgsh1a | vegclass, data = LRBsel)

??binford
colnames(LRBsel)
LRB <- LRBsel
# ONLY NOMADIC ####  
LRBnom <- LRBsel%>%filter(sed %in%c("Fully nomadic", "Semi-nomadic"))
scatterplot(density~nagp |vegclass, data = LRBnom)

# ONLY NOMADIC ####  
LRBnostor <- LRBsel%>%filter(store %in%c("None"))
scatterplot(density~nagp |vegclass, data = LRBnom)

# resource ownership
LRBsel$owners <- factor(LRBsel$owners,
                        levels=c("None reported",
                                 "Local group claims hunting areas, dominant animals, fishing sites and animal drive locations",
                                 "Local groups claims exclusive rights over resource locations, residential sites and home range",
                                 "Elite ownership of land and resources"
                                 ),
                        ordered=TRUE,
                        labels=c("None","Local claims","Local tenure","Elite tenure"))
plot(x=LRBsel$owners[!is.na(LRBsel$owners)],
     y=LRBsel$density[!is.na(LRBsel$owners)], type="p")
lines(lowess(LRBsel$nagp,
             LRBsel$density), col="red")
