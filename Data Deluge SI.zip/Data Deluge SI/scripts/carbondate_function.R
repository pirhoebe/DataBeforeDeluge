FindIndSampleHPDIntervals <- function(ident,
                                      output.calP_data,
                                      interval_width = "2sigma",
                                      bespoke_probability = NA) {
  
  if(interval_width == "bespoke" && is.na(bespoke_probability)) {
    stop("Chosen bespoke probability but not specified that probability")
  }
  
  n_iter <- output.calP_data$input_parameters$n_iter
  n_thin <- output.calP_data$input_parameters$n_thin
  n_burn <- floor(n_iter / (2 * n_thin))
  n_end <- floor(n_iter / n_thin) + 1
  
  rc_determinations <- output.calP_data$input_data$rc_determinations
  rc_sigmas <- output.calP_data$input_data$rc_sigmas
  F14C_inputs <-output.calP_data$input_data$F14C_inputs
  labcode <- output.calP_data$input_data$labcodes
    
  calendar_age_BP <- output.calP_data$calendar_ages[(n_burn+1):n_end, ident]
  rc_age <- rc_determinations[ident]
  rc_sig <- rc_sigmas[ident]
  
  if(output.calP_data$update_type == "RJPP") {
    bandwidth_selector <- "nrd0" # As all calendar ages are integers
  } else {
    bandwidth_selector <- "SJ" # As continuous
  }
  
  smoothed_density <- stats::density(calendar_age_BP, bw = bandwidth_selector)
  xrange_BP <- range(calendar_age_BP)
  
  hpd_probability <- switch(
    interval_width,
    "1sigma" = 0.682,
    "2sigma" = 0.954,
    "bespoke" = bespoke_probability)
  hpd <- carbondate:::FindHPD(smoothed_density$x, smoothed_density$y, hpd_probability)
  
  merged_hpd_intervals <- c(rbind(hpd$start_ages, hpd$end_ages))
  return(round(merged_hpd_intervals))
  
}



# Find matrix of intervals for a set of 14C samples/determinations (can change to dataframe is desired)
FindSetSamplesHPDIntervals <- function(ident_set,
                                       output.calP_data,
                                       interval_width = "2sigma",
                                       bespoke_probability = NA) {
  
  if(interval_width == "bespoke" && is.na(bespoke_probability)) {
    stop("Chosen bespoke probability but not specified that probability")
  }
  
  n_iter <- output.calP_data$input_parameters$n_iter
  n_thin <- output.calP_data$input_parameters$n_thin
  n_burn <- floor(n_iter / (2 * n_thin))
  n_end <- floor(n_iter / n_thin) + 1
  
  list_intervals <- lapply(ident_set,
                           FindIndSampleHPDIntervals,
                           output.calP_data = output.calP_data,
                           interval_width = interval_width,
                           bespoke_probability = bespoke_probability)
  
  # Convert ragged list to a dataframe/matrix with relevant name headings
  max_n_intervals <- max(lengths(list_intervals))
  interval_matrix <- t(sapply(list_intervals, "[", seq(max_n_intervals)))
  colnames(interval_matrix) <- paste(interval_width,
                                     rep(1:(max_n_intervals/2), each = 2),
                                     c("start", "end"),
                                     sep = "_")
  
  # Create matrix/dataframe with 14C determination information
  sample_info_matrix <- data.frame(sample_ident = ident_set,
                                   radiocarbon_age = output.calP_data$input_data$rc_determinations[ident_set],
                                   radiocarbon_sigma = output.calP_data$input_data$rc_sigmas[ident_set],
                                   labcode = output.calP_data$input_data$labcodes[ident_set])
  
  posterior_calendar_ages_ident_set <- output.calP_data$calendar_ages[(n_burn+1):n_end, ident_set]
  
  # Add columns with posterior mean and median calendar ages
  if(length(ident_set) == 1) { # Deal with case that posterior_calendar_ages_ident_set is a vector
    sample_info_matrix$posterior_calendar_age_mean <- round(mean(posterior_calendar_ages_ident_set),1)
    sample_info_matrix$posterior_calendar_age_median <- round(median(posterior_calendar_ages_ident_set))
  } else {
    sample_info_matrix$posterior_calendar_age_mean <- round(apply(posterior_calendar_ages_ident_set, 2, mean),1)
    sample_info_matrix$posterior_calendar_age_median <- round(apply(posterior_calendar_ages_ident_set, 2, median))
  }
  
  # Add column specifying determination information
  interval_matrix <- cbind(sample_info_matrix, interval_matrix)
  
  return(interval_matrix)
}


caldates <- function(data){
  output.calP<- FindSetSamplesHPDIntervals(1:length(data$input_data$rc_determinations), data)

  if("2sigma_6_end" %in% colnames(output.calP)){
    output.calP$calBPstart[!is.na(output.calP$`2sigma_6_end`)] <-
      output.calP$`2sigma_6_end`[!is.na(output.calP$`2sigma_6_end`)]}
  if("2sigma_5_end" %in% colnames(output.calP)){
    output.calP$calBPstart[!is.na(output.calP$`2sigma_5_end`)] <-
      output.calP$`2sigma_5_end`[!is.na(output.calP$`2sigma_5_end`)]}
  if("2sigma_4_end" %in% colnames(output.calP)){
    output.calP$calBPstart[!is.na(output.calP$`2sigma_4_end`)] <-
      output.calP$`2sigma_4_end`[!is.na(output.calP$`2sigma_4_end`)]}
  if("2sigma_3_end" %in% colnames(output.calP)){
    output.calP$calBPstart[!is.na(output.calP$`2sigma_3_end`)] <-
      output.calP$`2sigma_3_end`[!is.na(output.calP$`2sigma_3_end`)]}
  if("2sigma_2_end" %in% colnames(output.calP)){
    output.calP$calBPstart[!is.na(output.calP$`2sigma_2_end`)] <-
      output.calP$`2sigma_2_end`[!is.na(output.calP$`2sigma_2_end`)]}
  if("2sigma_1_end" %in% colnames(output.calP)){
    output.calP$calBPstart[!is.na(output.calP$`2sigma_1_end`)] <-
      output.calP$`2sigma_1_end`[!is.na(output.calP$`2sigma_1_end`)]}
  output.calP$calBPend <- output.calP$`2sigma_1_start`
  output.calP$calBPmean <- (output.calP$calBPend+output.calP$calBPstart)/2
  output.calP}

message("Function FindIndSampleHPDIntervals() added")
message("Function FindSetSamplesHPDIntervals() added")
message("Function caldates() added")
