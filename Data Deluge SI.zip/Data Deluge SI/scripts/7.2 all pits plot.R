#pit hearths outside NL
library("carbondate")
source("SupplMat scripts/PPcalibrate_custom.R")
data_pits.PP <- PPcalibrate_custom(rc_determinations = data_pits$c14age,
                                 rc_sigmas = data_pits$c14sd,
                                 labcodes=data_pits$labcode,
                                 calibration_curve = intcal20,
                                 calendar_grid_resolution = 1,
                                 n_iter=1e5,
                                 n_thin=10,
                                 show_progress = TRUE)
source("scripts/carbondate_function.R")
data_pits.calP<- caldates(data=data_pits.PP)
data_pits <- left_join(x=data_pits,
                          y=data_pits.calP[, c("labcode", "calBPstart", "calBPend", "calBPmean")],
                          by="labcode")
data_pits.PP_fit<- PlotPosteriorMeanRate(data_pits.PP)

source("SupplMat scripts/plotPP edit.R")

data_pits.PPCP<- plotPPCP(data_pits.PP, n_changes=6, llim=12500, ulim=6000, ActivateLegend = 0)

INTCAL20 <- read.csv('https://www.intcal.org/curves/intcal20.14c',
                     encoding="UTF-8",skip=11,header=F)
colnames(INTCAL20) <- c("BP","CRA","Error","D14C","Sigma")

data_pits<- data_pits

## POISSON PROCESS ####
layout.matrix <- matrix(c(1,2), nrow=2, ncol=1)
layout(mat=layout.matrix, heights=c(3,2), widths=c(2))
layout.show(8)
lowerlim=12500
upperlim=8000
# par(mfrow=c(4,2))
par(oma=c(1.5,1,1,1))
par(mar=c(2.5,3,2,3))

#______________________________________________________________________________
### data_pits ####
#______________________________________________________________________________
plot(x=INTCAL20$BP[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim], 
     y=INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim],
     xlim=rev(range(INTCAL20$BP[INTCAL20$BP<=lowerlim &
                                  INTCAL20$BP>=upperlim])),
     ylim=c(min(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])-2000,
            max(INTCAL20$CRA[INTCAL20$BP<=lowerlim & INTCAL20$BP>=upperlim])+1000),
     type="l", col="royalblue", lwd=2,
     axes= FALSE, xaxs="i",xlab="", ylab="")
axis(4, at=c(5000,6000, 7000, 8000,9000,10000, 11000),labels=TRUE,tck=-0.05,col="black", col.axis="royalblue")
axis(4, at=seq(5500,12500,by=1000), labels=FALSE,tck=-0.03,col="black", col.axis="royalblue")
axis(4, at = data_pits$c14age, labels = FALSE, tck=0.02)
mtext(expression(text=''^14*'C age BP'), side=4, line=3, col="royalblue", cex=0.7)
phaserect=1
rm(phaselabels)
lowerlim=12500
upperlim=6500

par(new=TRUE)
plot(x=data_pits.PP_fit$calendar_age_BP,
     y=data_pits.PP_fit$rate_mean,
     col="firebrick",
     lwd=2,
     type="l", 
     xaxs="i",
     xlim=c(12500, 6500),
     ylim=c(0,max(data_pits.PP_fit$rate_ci_upper+
                    (0.2*max(data_pits.PP_fit$rate_ci_upper)))),
     # ylim=c(0,1.75),
     ylab=NA,
     xlab=NA)
# abline(h=0)
mtext("density estimate", side=2, line=3, col="firebrick", cex=0.7)
mtext("a. pit hearths PP (n=799)", side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
polygon(x=c(data_pits.PP_fit$calendar_age_BP,
            rev(data_pits.PP_fit$calendar_age_BP)),
        y=c(data_pits.PP_fit$rate_ci_upper,
            rev(data_pits.PP_fit$rate_ci_lower)),
        col=rgb(1,0,0,0.3), 
        border=NA)
polygon(x=c(data_pits.PP_fit$calendar_age_BP,
            rev(data_pits.PP_fit$calendar_age_BP)),
        y=c(data_pits.PP_fit$rate_ci_upper,
            rev(data_pits.PP_fit$rate_ci_lower)),
        col=NA, 
        border="firebrick",
        lty=2)
lines(x=data_pits.PP_fit$calendar_age_BP,
      y=data_pits.PP_fit$rate_mean,
      col="firebrick",
      lwd=2)
for(i in 1:length(data_pits.PPCP)){
  if(data_pits.PPCP[[i]]$n_change==6){
    abline(v=data_pits.PPCP[[i]]$x[data_pits.PPCP[[i]]$y==max(data_pits.PPCP[[i]]$y)],
           lty=2, lwd=2,col="firebrick")}
  if(data_pits.PPCP[[i]]$n_change==5){
    abline(v=data_pits.PPCP[[i]]$x[data_pits.PPCP[[i]]$y==max(data_pits.PPCP[[i]]$y)],
           lty=2, lwd=2,col="firebrick")}
}
# par(xpd=NA)
source("scripts/phaserect-3.R")
# par(xpd=FALSE)
axis(1, at = data_pits$calBPmean, labels = FALSE, tck=0.02)
box()
axis(1, at = seq(6500,12500, by=1000), labels = FALSE, tck=-0.05)
axis(1, at = seq(6500, 12500, by=500), labels = FALSE, tck=-0.03)
axis(1, at = seq(6500,12500, by=100), labels = FALSE, tck=-0.015)

## POSTERIOR CHANGE POINTS ####
#______________________________________________________________________________

plot(x=c(lowerlim,upperlim), y=c(0,0.003), xlim=c(12500,6500),
     type="n", xaxs="i",yaxs="i",xlab="", ylab="")
source("scripts/phaserect-3.R")
axis(1, at = seq(6500,12500, by=1000), labels = FALSE, tck=-0.05*3)
axis(1, at = seq(6500, 12500, by=500), labels = FALSE, tck=-0.03*3)
axis(1, at = seq(6500,12500, by=100), labels = FALSE, tck=-0.015*3)
mtext(paste("b. Change Points"), side=3, line=1.5, col="black", cex=1, adj=0.1, padj=1)
mtext("Probability", side=2, line=3, col="black", cex=0.7)
for(i in 1:length(data_pits.PPCP)){
  if(data_pits.PPCP[[i]]$n_change==6){
    lines(x=data_pits.PPCP[[i]]$x,
          y=data_pits.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(1,0,0.6,0.5))
          col="firebrick")
    abline(v=data_pits.PPCP[[i]]$x[data_pits.PPCP[[i]]$y==max(data_pits.PPCP[[i]]$y)],
           lty=2, lwd=2,col="firebrick")}
  if(data_pits.PPCP[[i]]$n_change==5){
    lines(x=data_pits.PPCP[[i]]$x,
          y=data_pits.PPCP[[i]]$y,
          lty=2,lwd=2,
          # col=rgb(0.5, 0,0,0.5))
          col="firebrick")
    abline(v=data_pits.PPCP[[i]]$x[data_pits.PPCP[[i]]$y==max(data_pits.PPCP[[i]]$y)],
           lty=2, lwd=2,col="firebrick")}
}
box()

