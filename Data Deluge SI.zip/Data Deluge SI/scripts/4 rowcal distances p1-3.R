require(spatstat)
d<-function(coord) {
  # Calculate distances between all sets of sites with dates in the window
  dd<-pairdist(X=coord[,1], Y=coord[,2])
  dd<-dd[upper.tri(dd)]
  # Exclude any cases of two or more dates from the same site
  dd<-dd[dd>0]
  return(dd)
}


from <- -16000 # start date
to <- -6000 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)

#######################################
data <- Paper1
counter<- 1
dists<-c()
for(Y in seq(from=from,to=to,by=by)) {
  dists[counter]<-mean(
    d(data.frame(data$wgslon[data$median<Y & data$median>=Y-size],
                 data$wgslat[data$median<Y & data$median>=Y-size])
    ))
  counter<-counter+1
}
counter<- 1
lat <- c()
for(Y in seq(from=from,to=to,by=by)) {
  lat[counter]<-mean(data$wgslat[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
Paper1_dists <- dists
Paper1_lat <- lat


from <- -12500 # start date
to <- -6000 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)
###############
data <- Paper2W
counter<- 1
dists<-c()
for(Y in seq(from=from,to=to,by=by)) {
  dists[counter]<-mean(
    d(data.frame(data$wgslon[data$median<Y & data$median>=Y-size],
                 data$wgslat[data$median<Y & data$median>=Y-size])
    ))
  counter<-counter+1
}
counter<- 1
lat <- c()
for(Y in seq(from=from,to=to,by=by)) {
  lat[counter]<-mean(data$wgslat[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
Paper2W_dists <- dists
Paper2W_lat <- lat
###############
data <- Paper2E
counter<- 1
dists<-c()
for(Y in seq(from=from,to=to,by=by)) {
  dists[counter]<-mean(
    d(data.frame(data$wgslon[data$median<Y & data$median>=Y-size],
                 data$wgslat[data$median<Y & data$median>=Y-size])
    ))
  counter<-counter+1
}
counter<- 1
lat <- c()
for(Y in seq(from=from,to=to,by=by)) {
  lat[counter]<-mean(data$wgslat[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
Paper2E_dists <- dists
Paper2E_lat <- lat

################
data <- Paper3
counter<- 1
dists<-c()
for(Y in seq(from=from,to=to,by=by)) {
  dists[counter]<-mean(
    d(data.frame(data$wgslon[data$median<Y & data$median>=Y-size],
                 data$wgslat[data$median<Y & data$median>=Y-size])
    ))
  counter<-counter+1
}
counter<- 1
lat <- c()
for(Y in seq(from=from,to=to,by=by)) {
  lat[counter]<-mean(data$wgslat[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}
Paper3_dists <- dists
Paper3_lat <- lat



# Convert to km
#dists<-dists/1000
from <- -16000 # start date
to <- -6000 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)
###############################################################################
####PLOT #####
##############################################################################
par(mfrow=c(2,1))
par(mar=c(2,4.1,2,1))
par(oma=c(2,0,2,0))
l<-loess(Paper1_dists~years, span=0.15)
lp<-predict(l, se=TRUE)
# plot the output
plot(years, Paper1_dists, pch='.', ylab='kilometers',
     xlab='Cal. BP', 
     # xlim=c(-16000,-6000), 
     ylim=c(0,10))
# mtext("a. Mean intersite distance:", side=3, line=3, adj=0)
mtext("  a. Chapter II: mean intersite distance", side=3, line=-1.2, adj=0)
axis(1, at=seq(-16000, -6000, by=2000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-15500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-15500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
phaselabels=TRUE
ppos=-0.25
phasepl=2
source("scripts/phaserect.R")
rm(phaselabels)
phasepl=1
source("scripts/phaserect.R")
l<-loess(Paper1_lat~years, span=0.15)
lp<-predict(l, se=TRUE)

plot(years, Paper1_lat, pch='.', ylab='Latitude',
     xlab='Cal. BP', xlim=c(-16000,-6000), ylim=c(48,55))
# mtext("b. Mean site latitude:", side=3, line=3, adj=0)
mtext("  b. Chapter II: mean site latitude", side=3, line=-1.2, adj=0)
axis(1, at=seq(-16000, -6000, by=2000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-15500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-15500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
rm(phaselabels)
phasepl=1
source("scripts/phaserect.R")
#_____________________________________________________________________________
# HOLOCENE
from <- -12500 # start date
to <- -6000 # end date
by <- 5 # step increment (in years)
size <- 100 # size of moving window (in years)
years <- seq(from=from,to=to,by=by)
par(mfrow=c(3,2))
par(mar=c(2,4.1,2.5,1))
par(oma=c(2,0,3,0))
##################################
# plot the output
l<-loess(Paper2W_dists~years, span=0.15)
lp<-predict(l, se=TRUE)
# plot the output
plot(years, Paper2W_dists, pch='.', ylab='kilometers',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(0,4))
mtext("a. Mean intersite distance:", side=3, line=3, adj=0)
mtext("   Chapter IV West data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
phaselabels=TRUE
ppos=-0.25
phasepl=2
source("scripts/phaserect2.R")
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")
l<-loess(Paper2W_lat~years, span=0.15)
lp<-predict(l, se=TRUE)

plot(years, Paper2W_lat, pch='.', ylab='Latitude',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(51,55))
mtext("b. Mean site latitude:", side=3, line=3, adj=0)
mtext("   Chapter IV West data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
phaselabels=TRUE
ppos=-0.18
phasepl=2
source("scripts/phaserect2.R")
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")
##############################
l<-loess(Paper2E_dists~years, span=0.15)
lp<-predict(l, se=TRUE)
# plot the output
plot(years, Paper2E_dists, pch='.', ylab='kilometers',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(0,4))
mtext("   Chapter IV East data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")
l<-loess(Paper2E_lat~years, span=0.15)
lp<-predict(l, se=TRUE)

plot(years, Paper2E_lat, pch='.', ylab='Latitude',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(51,55))
mtext("   Chapter IV East data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")

##############################
l<-loess(Paper3_dists~years, span=0.15)
lp<-predict(l, se=TRUE)
# plot the output
plot(years, Paper3_dists, pch='.', ylab='kilometers',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(0,3))
mtext("   Chapter V data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")
l<-loess(Paper3_lat~years, span=0.15)
lp<-predict(l, se=TRUE)
plot(years, Paper3_lat, pch='.', ylab='Latitude',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(51,53))
mtext("   Chapter V data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")

##############################################################################
# LON
##############################
################
data <- Paper3
counter<- 1
# dists<-c()
# for(Y in seq(from=from,to=to,by=by)) {
#   dists[counter]<-mean(
#     d(data.frame(data$wgslon[data$median<Y & data$median>=Y-size],
#                  data$wgslat[data$median<Y & data$median>=Y-size])
#     ))
#   counter<-counter+1
# }
# counter<- 1
lon <- c()
for(Y in seq(from=from,to=to,by=by)) {
  lon[counter]<-mean(data$wgslon[data$median<Y & data$median>=Y-size])
  counter<-counter+1
}

Paper3_lon <- lon
par(mfrow=c(2,1))
l<-loess(Paper3_lat~years, span=0.15)
lp<-predict(l, se=TRUE)
# plot the output
plot(years, Paper3_lat, pch='.', ylab='kilometers',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(51,53))
mtext("   Chapter V data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")
l<-loess(Paper3_lon~years, span=0.15)
lp<-predict(l, se=TRUE)
plot(years, Paper3_lon, pch='.', ylab='Longitude',
     xlab='Cal. BP', xlim=c(-12500,-6000), ylim=c(3,7))
mtext("   Chapter V data", side=3, line=-1.2, adj=0, cex=0.8)
axis(1, at=seq(-12000, -6000, by=1000), labels=TRUE, tck=-0.05)
axis(1, at=seq(-12500, -6000, by=500), labels=FALSE, tck=-0.03)
axis(1, at=seq(-12500, -6000, by=100), labels=FALSE, tck=-0.01)
lines(l$x,lp$fit, lwd=1.5)
lines(l$x,lp$fit+lp$se.fit,lty=2, lwd=1.5)
lines(l$x,lp$fit-lp$se.fit,lty=2, lwd=1.5)
rowcalBC="BP"
rm(phaselabels)
phasepl=1
source("scripts/phaserect2.R")

